<?php
/**
 * Plugin Name: JD Transcripts API Backend
 * Plugin URI: https://jdlegaltranscripts.com
 * Description: Complete backend API functionality for JD Legal Transcripts - replaces Node.js backend
 * Version: 1.0.0
 * Author: JD Legal Transcripts
 * License: GPL v2 or later
 * Text Domain: jd-transcripts-api
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('JD_API_PLUGIN_URL', plugin_dir_url(__FILE__));
define('JD_API_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('JD_API_VERSION', '1.0.0');

/**
 * Main Plugin Class
 */
class JD_Transcripts_API {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('rest_api_init', array($this, 'register_api_routes'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        $this->create_custom_post_types();
        $this->create_custom_roles();
        $this->setup_cors();
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        $this->create_database_tables();
        $this->create_default_admin_user();
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Setup CORS for API requests
     */
    public function setup_cors() {
        add_action('rest_api_init', function() {
            remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
            add_filter('rest_pre_serve_request', function($value) {
                $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
                $allowed_origins = array(
                    'https://jdreporting.org',
                    'https://www.jdreporting.org'
                );
                if (in_array($origin, $allowed_origins, true)) {
                    header('Access-Control-Allow-Origin: ' . $origin);
                } else {
                    header('Access-Control-Allow-Origin: https://jdreporting.org');
                }
                header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
                header('Access-Control-Allow-Headers: Content-Type, Authorization, X-WP-Nonce');
                header('Access-Control-Allow-Credentials: true');

                // Handle preflight requests quickly
                if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
                    status_header(200);
                    exit;
                }
                return $value;
            });
        }, 15);
    }
    
    /**
     * Create custom post types
     */
    public function create_custom_post_types() {
        // Orders Post Type
        register_post_type('jd_order', array(
            'labels' => array(
                'name' => 'Orders',
                'singular_name' => 'Order',
                'add_new' => 'Add New Order',
                'add_new_item' => 'Add New Order',
                'edit_item' => 'Edit Order',
                'new_item' => 'New Order',
                'view_item' => 'View Order',
                'search_items' => 'Search Orders',
                'not_found' => 'No orders found',
                'not_found_in_trash' => 'No orders found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-clipboard',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'orders',
        ));
        
        // Transcribers Post Type
        register_post_type('jd_transcriber', array(
            'labels' => array(
                'name' => 'Transcribers',
                'singular_name' => 'Transcriber',
                'add_new' => 'Add New Transcriber',
                'add_new_item' => 'Add New Transcriber',
                'edit_item' => 'Edit Transcriber',
                'new_item' => 'New Transcriber',
                'view_item' => 'View Transcriber',
                'search_items' => 'Search Transcribers',
                'not_found' => 'No transcribers found',
                'not_found_in_trash' => 'No transcribers found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-microphone',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'transcribers',
        ));
        
        // Job Applications Post Type
        register_post_type('jd_job_application', array(
            'labels' => array(
                'name' => 'Job Applications',
                'singular_name' => 'Job Application',
                'add_new' => 'Add New Application',
                'add_new_item' => 'Add New Application',
                'edit_item' => 'Edit Application',
                'new_item' => 'New Application',
                'view_item' => 'View Application',
                'search_items' => 'Search Applications',
                'not_found' => 'No applications found',
                'not_found_in_trash' => 'No applications found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-businessman',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'job-applications',
        ));
        
        // Job Positions Post Type
        register_post_type('jd_job_position', array(
            'labels' => array(
                'name' => 'Job Positions',
                'singular_name' => 'Job Position',
                'add_new' => 'Add New Position',
                'add_new_item' => 'Add New Position',
                'edit_item' => 'Edit Position',
                'new_item' => 'New Position',
                'view_item' => 'View Position',
                'search_items' => 'Search Positions',
                'not_found' => 'No positions found',
                'not_found_in_trash' => 'No positions found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-portfolio',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'job-positions',
        ));
        
        // Contact Form Submissions Post Type
        register_post_type('jd_contact_form', array(
            'labels' => array(
                'name' => 'Contact Forms',
                'singular_name' => 'Contact Form',
                'add_new' => 'Add New Contact',
                'add_new_item' => 'Add New Contact',
                'edit_item' => 'Edit Contact',
                'new_item' => 'New Contact',
                'view_item' => 'View Contact',
                'search_items' => 'Search Contacts',
                'not_found' => 'No contacts found',
                'not_found_in_trash' => 'No contacts found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-email-alt',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'contact-forms',
        ));
        
        // Quote Requests Post Type
        register_post_type('jd_quote_request', array(
            'labels' => array(
                'name' => 'Quote Requests',
                'singular_name' => 'Quote Request',
                'add_new' => 'Add New Quote',
                'add_new_item' => 'Add New Quote',
                'edit_item' => 'Edit Quote',
                'new_item' => 'New Quote',
                'view_item' => 'View Quote',
                'search_items' => 'Search Quotes',
                'not_found' => 'No quotes found',
                'not_found_in_trash' => 'No quotes found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-money-alt',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'quote-requests',
        ));
        
        // Newsletter Subscriptions Post Type
        register_post_type('jd_newsletter_sub', array(
            'labels' => array(
                'name' => 'Newsletter Subscriptions',
                'singular_name' => 'Newsletter Subscription',
                'add_new' => 'Add New Subscription',
                'add_new_item' => 'Add New Subscription',
                'edit_item' => 'Edit Subscription',
                'new_item' => 'New Subscription',
                'view_item' => 'View Subscription',
                'search_items' => 'Search Subscriptions',
                'not_found' => 'No subscriptions found',
                'not_found_in_trash' => 'No subscriptions found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-email',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'newsletter-subscriptions',
        ));
        
        // Email Log Post Type
        register_post_type('jd_email_log', array(
            'labels' => array(
                'name' => 'Email Logs',
                'singular_name' => 'Email Log',
                'add_new' => 'Add New Log',
                'add_new_item' => 'Add New Log',
                'edit_item' => 'Edit Log',
                'new_item' => 'New Log',
                'view_item' => 'View Log',
                'search_items' => 'Search Logs',
                'not_found' => 'No logs found',
                'not_found_in_trash' => 'No logs found in Trash',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-admin-tools',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'custom-fields'),
            'has_archive' => false,
            'rewrite' => false,
            'show_in_rest' => true,
            'rest_base' => 'email-logs',
        ));
    }
    
    /**
     * Create custom user roles
     */
    public function create_custom_roles() {
        // Transcriber role
        add_role('transcriber', 'Transcriber', array(
            'read' => true,
            'edit_posts' => false,
            'delete_posts' => false,
        ));
        
        // Manager role
        add_role('jd_manager', 'JD Manager', array(
            'read' => true,
            'edit_posts' => true,
            'delete_posts' => true,
            'edit_others_posts' => true,
            'publish_posts' => true,
            'manage_categories' => true,
            'edit_jd_orders' => true,
            'edit_others_jd_orders' => true,
            'publish_jd_orders' => true,
            'read_private_jd_orders' => true,
        ));
    }
    
    /**
     * Create database tables for additional data
     */
    public function create_database_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Order timeline table
        $table_name = $wpdb->prefix . 'jd_order_timeline';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            action varchar(255) NOT NULL,
            performed_by varchar(255) NOT NULL,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Transcriber statistics table
        $table_name = $wpdb->prefix . 'jd_transcriber_stats';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            transcriber_id bigint(20) NOT NULL,
            total_orders int(11) DEFAULT 0,
            completed_orders int(11) DEFAULT 0,
            average_rating decimal(3,2) DEFAULT 0.00,
            total_earnings decimal(10,2) DEFAULT 0.00,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY transcriber_id (transcriber_id)
        ) $charset_collate;";
        
        dbDelta($sql);
    }
    
    /**
     * Create default admin user
     */
    public function create_default_admin_user() {
        $admin_email = 'admin@jdlegaltranscripts.com';
        $admin_username = 'jd_admin';
        
        if (!username_exists($admin_username) && !email_exists($admin_email)) {
            $user_id = wp_create_user($admin_username, wp_generate_password(), $admin_email);
            if (!is_wp_error($user_id)) {
                $user = new WP_User($user_id);
                $user->set_role('administrator');
                update_user_meta($user_id, 'first_name', 'JD');
                update_user_meta($user_id, 'last_name', 'Admin');
            }
        }
    }
    
    /**
     * Register API routes
     */
    public function register_api_routes() {
        // Include API route files
        require_once JD_API_PLUGIN_PATH . 'includes/api/orders.php';
        require_once JD_API_PLUGIN_PATH . 'includes/api/auth.php';
        require_once JD_API_PLUGIN_PATH . 'includes/api/admin.php';
        require_once JD_API_PLUGIN_PATH . 'includes/api/transcribers.php';
        require_once JD_API_PLUGIN_PATH . 'includes/api/careers.php';
        require_once JD_API_PLUGIN_PATH . 'includes/api/email.php';
        
        // Initialize API classes
        new JD_API_Orders();
        new JD_API_Auth();
        new JD_API_Admin();
        new JD_API_Transcribers();
        new JD_API_Careers();
        new JD_API_Email();
    }
}

// Include installer
require_once JD_API_PLUGIN_PATH . 'install.php';

// Initialize the plugin
new JD_Transcripts_API();

/**
 * Helper Functions
 */

/**
 * Generate unique order ID
 */
function jd_generate_order_id() {
    return 'JD' . date('Ymd') . '-' . wp_rand(1000, 9999);
}

/**
 * Get order by order ID
 */
function jd_get_order_by_id($order_id) {
    $posts = get_posts(array(
        'post_type' => 'jd_order',
        'meta_query' => array(
            array(
                'key' => '_order_id',
                'value' => $order_id,
                'compare' => '='
            )
        ),
        'posts_per_page' => 1
    ));
    
    return !empty($posts) ? $posts[0] : null;
}

/**
 * Send email notification
 */
function jd_send_email_notification($to, $subject, $message, $headers = array()) {
    $default_headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: JD Legal Transcripts <noreply@jdlegaltranscripts.com>'
    );
    
    $headers = array_merge($default_headers, $headers);
    
    return wp_mail($to, $subject, $message, $headers);
}

/**
 * Validate JWT token (simplified version)
 */
function jd_validate_jwt_token($token) {
    // For now, we'll use WordPress nonces and sessions
    // In production, you might want to implement proper JWT
    $user_id = wp_validate_auth_cookie($token, 'logged_in');
    return $user_id ? get_user_by('id', $user_id) : false;
}

/**
 * Check if user is admin
 */
function jd_is_admin_user($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    
    $user = get_user_by('id', $user_id);
    return $user && (in_array('administrator', $user->roles) || in_array('jd_manager', $user->roles));
}