<?php
/**
 * Email API Endpoints
 * Replaces Node.js /api/email routes
 */

class JD_API_Email {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // POST /api/email/contact - Send contact form email
        register_rest_route($namespace, '/email/contact', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_contact_email'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'name' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'phone' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'subject' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'message' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'service' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // POST /api/email/quote - Send quote request email
        register_rest_route($namespace, '/email/quote', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_quote_request'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'name' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'phone' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'serviceType' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'turnaround' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'audioLength' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'details' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // POST /api/email/newsletter - Subscribe to newsletter
        register_rest_route($namespace, '/email/newsletter', array(
            'methods' => 'POST',
            'callback' => array($this, 'subscribe_newsletter'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'name' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // POST /api/email/send-custom - Send custom email (admin only)
        register_rest_route($namespace, '/email/send-custom', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_custom_email'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'to' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'subject' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'message' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'wp_kses_post',
                ),
                'template' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/email/templates - Get email templates (admin only)
        register_rest_route($namespace, '/email/templates', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_email_templates'),
            'permission_callback' => array($this, 'check_admin_permission'),
        ));
        
        // POST /api/email/test - Test email configuration (admin only)
        register_rest_route($namespace, '/email/test', array(
            'methods' => 'POST',
            'callback' => array($this, 'test_email_config'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'to' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
            ),
        ));
    }
    
    /**
     * Send contact form email
     */
    public function send_contact_email($request) {
        try {
            $params = $request->get_params();
            
            // Store contact form submission
            $this->store_contact_submission($params);
            
            // Send email to admin
            $admin_email = get_option('admin_email');
            $subject = 'New Contact Form Submission - ' . ($params['subject'] ?: 'General Inquiry');
            
            $message = $this->get_contact_email_template($params);
            
            $sent = jd_send_email_notification($admin_email, $subject, $message);
            
            if (!$sent) {
                return new WP_Error('email_send_failed', 'Failed to send email', array('status' => 500));
            }
            
            // Send confirmation email to user
            $this->send_contact_confirmation($params);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Contact form submitted successfully',
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('contact_email_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Send quote request email
     */
    public function send_quote_request($request) {
        try {
            $params = $request->get_params();
            
            // Store quote request
            $this->store_quote_request($params);
            
            // Send email to admin
            $admin_email = get_option('admin_email');
            $subject = 'New Quote Request - ' . $params['serviceType'];
            
            $message = $this->get_quote_email_template($params);
            
            $sent = jd_send_email_notification($admin_email, $subject, $message);
            
            if (!$sent) {
                return new WP_Error('email_send_failed', 'Failed to send quote request', array('status' => 500));
            }
            
            // Send confirmation email to user
            $this->send_quote_confirmation($params);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Quote request submitted successfully',
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('quote_email_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Subscribe to newsletter
     */
    public function subscribe_newsletter($request) {
        try {
            $params = $request->get_params();
            
            // Check if email already subscribed
            $existing = get_posts(array(
                'post_type' => 'jd_newsletter_sub',
                'meta_query' => array(
                    array(
                        'key' => '_email',
                        'value' => $params['email'],
                        'compare' => '=',
                    ),
                ),
                'posts_per_page' => 1,
            ));
            
            if (!empty($existing)) {
                return new WP_REST_Response(array(
                    'success' => true,
                    'message' => 'You are already subscribed to our newsletter',
                ), 200);
            }
            
            // Store newsletter subscription
            $this->store_newsletter_subscription($params);
            
            // Send welcome email
            $this->send_newsletter_welcome($params);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Successfully subscribed to newsletter',
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('newsletter_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Send custom email (admin only)
     */
    public function send_custom_email($request) {
        try {
            $params = $request->get_params();
            
            $to = $params['to'];
            $subject = $params['subject'];
            $message = $params['message'];
            $template = $params['template'] ?? 'default';
            
            // Apply template if specified
            if ($template !== 'plain') {
                $message = $this->apply_email_template($message, $template);
            }
            
            $sent = jd_send_email_notification($to, $subject, $message);
            
            if (!$sent) {
                return new WP_Error('email_send_failed', 'Failed to send email', array('status' => 500));
            }
            
            // Log email sending
            $this->log_email_sent($to, $subject, get_current_user_id());
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Email sent successfully',
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('custom_email_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get email templates
     */
    public function get_email_templates($request) {
        $templates = array(
            'default' => array(
                'name' => 'Default Template',
                'description' => 'Standard JD Legal Transcripts email template',
            ),
            'notification' => array(
                'name' => 'Notification Template',
                'description' => 'For system notifications and alerts',
            ),
            'marketing' => array(
                'name' => 'Marketing Template',
                'description' => 'For promotional and marketing emails',
            ),
            'plain' => array(
                'name' => 'Plain Text',
                'description' => 'No template, plain text email',
            ),
        );
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $templates,
        ), 200);
    }
    
    /**
     * Test email configuration
     */
    public function test_email_config($request) {
        try {
            $to = $request['to'] ?: get_option('admin_email');
            $subject = 'Email Configuration Test - JD Legal Transcripts';
            
            $message = '<h2>Email Test</h2>
                       <p>This is a test email to verify your email configuration is working correctly.</p>
                       <p><strong>Sent at:</strong> ' . current_time('F j, Y g:i a') . '</p>
                       <p>If you received this email, your configuration is working properly.</p>';
            
            $sent = jd_send_email_notification($to, $subject, $message);
            
            if (!$sent) {
                return new WP_Error('email_test_failed', 'Email test failed', array('status' => 500));
            }
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Test email sent successfully to ' . $to,
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('email_test_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Helper Functions
     */
    
    private function store_contact_submission($data) {
        $post_id = wp_insert_post(array(
            'post_title' => 'Contact from ' . $data['name'],
            'post_content' => $data['message'],
            'post_status' => 'publish',
            'post_type' => 'jd_contact_form',
            'post_author' => 1,
        ));
        
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_name', $data['name']);
            update_post_meta($post_id, '_email', $data['email']);
            update_post_meta($post_id, '_phone', $data['phone'] ?? '');
            update_post_meta($post_id, '_subject', $data['subject'] ?? '');
            update_post_meta($post_id, '_service', $data['service'] ?? '');
            update_post_meta($post_id, '_submitted_at', current_time('mysql'));
        }
    }
    
    private function store_quote_request($data) {
        $post_id = wp_insert_post(array(
            'post_title' => 'Quote Request from ' . $data['name'],
            'post_content' => $data['details'] ?? '',
            'post_status' => 'publish',
            'post_type' => 'jd_quote_request',
            'post_author' => 1,
        ));
        
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_name', $data['name']);
            update_post_meta($post_id, '_email', $data['email']);
            update_post_meta($post_id, '_phone', $data['phone'] ?? '');
            update_post_meta($post_id, '_service_type', $data['serviceType']);
            update_post_meta($post_id, '_turnaround', $data['turnaround']);
            update_post_meta($post_id, '_audio_length', $data['audioLength'] ?? '');
            update_post_meta($post_id, '_submitted_at', current_time('mysql'));
        }
    }
    
    private function store_newsletter_subscription($data) {
        $post_id = wp_insert_post(array(
            'post_title' => 'Newsletter Subscription - ' . $data['email'],
            'post_content' => '',
            'post_status' => 'publish',
            'post_type' => 'jd_newsletter_sub',
            'post_author' => 1,
        ));
        
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_email', $data['email']);
            update_post_meta($post_id, '_name', $data['name'] ?? '');
            update_post_meta($post_id, '_subscribed_at', current_time('mysql'));
            update_post_meta($post_id, '_status', 'active');
        }
    }
    
    private function get_contact_email_template($data) {
        return sprintf(
            '<h2>New Contact Form Submission</h2>
            <p><strong>Name:</strong> %s</p>
            <p><strong>Email:</strong> %s</p>
            <p><strong>Phone:</strong> %s</p>
            <p><strong>Subject:</strong> %s</p>
            <p><strong>Service Interest:</strong> %s</p>
            <p><strong>Message:</strong></p>
            <div style="background: #f5f5f5; padding: 15px; border-left: 4px solid #0073aa;">
                %s
            </div>
            <p><strong>Submitted:</strong> %s</p>',
            $data['name'],
            $data['email'],
            $data['phone'] ?: 'Not provided',
            $data['subject'] ?: 'General Inquiry',
            $data['service'] ?: 'Not specified',
            nl2br($data['message']),
            current_time('F j, Y g:i a')
        );
    }
    
    private function get_quote_email_template($data) {
        return sprintf(
            '<h2>New Quote Request</h2>
            <p><strong>Name:</strong> %s</p>
            <p><strong>Email:</strong> %s</p>
            <p><strong>Phone:</strong> %s</p>
            <p><strong>Service Type:</strong> %s</p>
            <p><strong>Turnaround:</strong> %s</p>
            <p><strong>Audio Length:</strong> %s</p>
            <p><strong>Additional Details:</strong></p>
            <div style="background: #f5f5f5; padding: 15px; border-left: 4px solid #0073aa;">
                %s
            </div>
            <p><strong>Submitted:</strong> %s</p>',
            $data['name'],
            $data['email'],
            $data['phone'] ?: 'Not provided',
            $data['serviceType'],
            $data['turnaround'],
            $data['audioLength'] ?: 'Not specified',
            nl2br($data['details'] ?: 'None provided'),
            current_time('F j, Y g:i a')
        );
    }
    
    private function send_contact_confirmation($data) {
        $subject = 'Thank you for contacting JD Legal Transcripts';
        
        $message = sprintf(
            '<h2>Thank You for Your Message</h2>
            <p>Dear %s,</p>
            <p>Thank you for contacting JD Legal Transcripts. We have received your message and will respond within 24 hours.</p>
            <p><strong>Your Message:</strong></p>
            <div style="background: #f5f5f5; padding: 15px; border-left: 4px solid #0073aa;">
                %s
            </div>
            <p>If you have any urgent questions, please call us directly.</p>
            <p>Best regards,<br>JD Legal Transcripts Team</p>',
            $data['name'],
            nl2br($data['message'])
        );
        
        jd_send_email_notification($data['email'], $subject, $message);
    }
    
    private function send_quote_confirmation($data) {
        $subject = 'Quote Request Received - JD Legal Transcripts';
        
        $message = sprintf(
            '<h2>Quote Request Received</h2>
            <p>Dear %s,</p>
            <p>Thank you for your quote request for <strong>%s</strong> services.</p>
            <p>We will review your requirements and send you a detailed quote within 2-4 hours.</p>
            <p><strong>Your Request Details:</strong></p>
            <ul>
                <li><strong>Service:</strong> %s</li>
                <li><strong>Turnaround:</strong> %s</li>
                <li><strong>Audio Length:</strong> %s</li>
            </ul>
            <p>If you have any questions, please feel free to contact us.</p>
            <p>Best regards,<br>JD Legal Transcripts Team</p>',
            $data['name'],
            $data['serviceType'],
            $data['serviceType'],
            $data['turnaround'],
            $data['audioLength'] ?: 'Not specified'
        );
        
        jd_send_email_notification($data['email'], $subject, $message);
    }
    
    private function send_newsletter_welcome($data) {
        $subject = 'Welcome to JD Legal Transcripts Newsletter';
        
        $message = sprintf(
            '<h2>Welcome to Our Newsletter</h2>
            <p>Dear %s,</p>
            <p>Thank you for subscribing to the JD Legal Transcripts newsletter!</p>
            <p>You will now receive:</p>
            <ul>
                <li>Industry insights and legal transcription tips</li>
                <li>Special offers and discounts</li>
                <li>Company updates and new service announcements</li>
            </ul>
            <p>We respect your privacy and will never share your email address.</p>
            <p>Welcome aboard!</p>
            <p>Best regards,<br>JD Legal Transcripts Team</p>',
            $data['name'] ?: 'Subscriber'
        );
        
        jd_send_email_notification($data['email'], $subject, $message);
    }
    
    private function apply_email_template($content, $template) {
        $templates = array(
            'default' => '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                            <div style="background: #0073aa; color: white; padding: 20px; text-align: center;">
                                <h1>JD Legal Transcripts</h1>
                            </div>
                            <div style="padding: 20px; background: white;">
                                %s
                            </div>
                            <div style="background: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #666;">
                                <p>JD Legal Transcripts | Professional Transcription Services</p>
                            </div>
                          </div>',
            'notification' => '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #ddd;">
                                <div style="background: #f39c12; color: white; padding: 15px;">
                                    <h2 style="margin: 0;">Notification</h2>
                                </div>
                                <div style="padding: 20px;">
                                    %s
                                </div>
                              </div>',
            'marketing' => '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                             <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center;">
                                 <h1 style="margin: 0;">JD Legal Transcripts</h1>
                                 <p style="margin: 10px 0 0 0;">Professional Transcription Services</p>
                             </div>
                             <div style="padding: 30px; background: white;">
                                 %s
                             </div>
                           </div>',
        );
        
        return sprintf($templates[$template] ?? $templates['default'], $content);
    }
    
    private function log_email_sent($to, $subject, $sent_by) {
        $post_id = wp_insert_post(array(
            'post_title' => 'Email Log - ' . $subject,
            'post_content' => '',
            'post_status' => 'publish',
            'post_type' => 'jd_email_log',
            'post_author' => $sent_by,
        ));
        
        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_to', $to);
            update_post_meta($post_id, '_subject', $subject);
            update_post_meta($post_id, '_sent_by', $sent_by);
            update_post_meta($post_id, '_sent_at', current_time('mysql'));
        }
    }
    
    public function check_admin_permission($request) {
        return current_user_can('manage_options') || jd_is_admin_user();
    }
}