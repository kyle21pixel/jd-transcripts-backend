<?php
/**
 * Orders API Endpoints
 * Replaces Node.js /api/orders routes
 */

class JD_API_Orders {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // POST /api/orders - Create new order
        register_rest_route($namespace, '/orders', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_order'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'clientName' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'clientEmail' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'clientPhone' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'serviceType' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'turnaround' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'estimatedCost' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'instructions' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // GET /api/orders - Get all orders (admin only)
        register_rest_route($namespace, '/orders', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_orders'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'status' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 10,
                ),
                'search' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/orders/{id} - Get single order
        register_rest_route($namespace, '/orders/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_order'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PUT /api/orders/{id}/assign - Assign order to transcriber
        register_rest_route($namespace, '/orders/(?P<id>[a-zA-Z0-9-]+)/assign', array(
            'methods' => 'PUT',
            'callback' => array($this, 'assign_order'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'transcriberID' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'priority' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'normal',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'notes' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // PUT /api/orders/{id}/status - Update order status
        register_rest_route($namespace, '/orders/(?P<id>[a-zA-Z0-9-]+)/status', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_order_status'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'status' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'notes' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // GET /api/orders/stats/dashboard - Get dashboard statistics
        register_rest_route($namespace, '/orders/stats/dashboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_dashboard_stats'),
            'permission_callback' => array($this, 'check_admin_permission'),
        ));
    }
    
    /**
     * Create new order
     */
    public function create_order($request) {
        try {
            $params = $request->get_params();
            
            // Generate unique order ID
            $order_id = jd_generate_order_id();
            
            // Calculate due date based on turnaround
            $due_date = new DateTime();
            $turnaround_hours = 24; // Default
            
            if (strpos($params['turnaround'], 'same-day') !== false) {
                $turnaround_hours = 8;
            } elseif (strpos($params['turnaround'], '24') !== false) {
                $turnaround_hours = 24;
            } elseif (strpos($params['turnaround'], '48') !== false) {
                $turnaround_hours = 48;
            } elseif (strpos($params['turnaround'], '3-5') !== false) {
                $turnaround_hours = 120; // 5 days
            }
            
            $due_date->add(new DateInterval('PT' . $turnaround_hours . 'H'));
            
            // Create order post
            $post_id = wp_insert_post(array(
                'post_title' => sprintf('Order from %s - %s', $params['clientName'], $order_id),
                'post_content' => $params['instructions'] ?? '',
                'post_status' => 'publish',
                'post_type' => 'jd_order',
                'post_author' => 1, // System user
            ));
            
            if (is_wp_error($post_id)) {
                return new WP_Error('order_creation_failed', 'Failed to create order', array('status' => 500));
            }
            
            // Save order metadata
            update_post_meta($post_id, '_order_id', $order_id);
            update_post_meta($post_id, '_client_name', $params['clientName']);
            update_post_meta($post_id, '_client_email', $params['clientEmail']);
            update_post_meta($post_id, '_client_phone', $params['clientPhone'] ?? '');
            update_post_meta($post_id, '_service_type', $params['serviceType']);
            update_post_meta($post_id, '_turnaround', $params['turnaround']);
            update_post_meta($post_id, '_estimated_cost', $params['estimatedCost'] ?? '');
            update_post_meta($post_id, '_status', 'pending');
            update_post_meta($post_id, '_due_date', $due_date->format('Y-m-d H:i:s'));
            update_post_meta($post_id, '_created_at', current_time('mysql'));
            
            // Add timeline entry
            $this->add_timeline_entry($post_id, 'Order Created', 'System', 'Order submitted by client');
            
            // Send email notification to admin
            $this->send_new_order_notification($order_id, $params);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Order created successfully',
                'data' => array(
                    'orderId' => $order_id,
                    'status' => 'pending',
                    'dueDate' => $due_date->format('c'),
                ),
            ), 201);
            
        } catch (Exception $e) {
            return new WP_Error('order_creation_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get orders with filtering and pagination
     */
    public function get_orders($request) {
        $params = $request->get_params();
        
        $args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => $params['limit'],
            'paged' => $params['page'],
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        // Filter by status
        if (!empty($params['status']) && $params['status'] !== 'all') {
            $args['meta_query'] = array(
                array(
                    'key' => '_status',
                    'value' => $params['status'],
                    'compare' => '=',
                ),
            );
        }
        
        // Search functionality
        if (!empty($params['search'])) {
            $args['meta_query'] = array(
                'relation' => 'OR',
                array(
                    'key' => '_order_id',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
                array(
                    'key' => '_client_name',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
                array(
                    'key' => '_client_email',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
            );
        }
        
        $query = new WP_Query($args);
        $orders = array();
        
        foreach ($query->posts as $post) {
            $orders[] = $this->format_order_data($post);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $orders,
            'pagination' => array(
                'current' => intval($params['page']),
                'pages' => $query->max_num_pages,
                'total' => $query->found_posts,
            ),
        ), 200);
    }
    
    /**
     * Get single order
     */
    public function get_order($request) {
        $order_id = $request['id'];
        $post = jd_get_order_by_id($order_id);
        
        if (!$post) {
            return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
        }
        
        $order_data = $this->format_order_data($post);
        
        // Add timeline data
        $order_data['timeline'] = $this->get_order_timeline($post->ID);
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $order_data,
        ), 200);
    }
    
    /**
     * Assign order to transcriber
     */
    public function assign_order($request) {
        $order_id = $request['id'];
        $transcriber_id = $request['transcriberID'];
        $priority = $request['priority'];
        $notes = $request['notes'];
        
        $post = jd_get_order_by_id($order_id);
        if (!$post) {
            return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
        }
        
        // Find transcriber
        $transcriber_post = $this->get_transcriber_by_id($transcriber_id);
        if (!$transcriber_post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        $transcriber_name = get_post_meta($transcriber_post->ID, '_name', true);
        
        // Update order
        update_post_meta($post->ID, '_assigned_to', $transcriber_post->ID);
        update_post_meta($post->ID, '_assigned_transcriber_name', $transcriber_name);
        update_post_meta($post->ID, '_status', 'in-progress');
        update_post_meta($post->ID, '_priority', $priority);
        
        if ($notes) {
            $current_instructions = get_post_meta($post->ID, '_instructions', true);
            update_post_meta($post->ID, '_instructions', $current_instructions . "\n\nAdmin Notes: " . $notes);
        }
        
        // Add timeline entry
        $current_user = wp_get_current_user();
        $this->add_timeline_entry(
            $post->ID, 
            'Order Assigned', 
            $current_user->user_login, 
            "Assigned to {$transcriber_name} with {$priority} priority"
        );
        
        // Update transcriber statistics
        $this->update_transcriber_stats($transcriber_post->ID, 'total_orders', 1);
        
        // Send assignment notification
        $this->send_assignment_notification($post, $transcriber_post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Order assigned successfully',
            'data' => array(
                'orderId' => $order_id,
                'assignedTo' => $transcriber_name,
                'status' => 'in-progress',
            ),
        ), 200);
    }
    
    /**
     * Update order status
     */
    public function update_order_status($request) {
        $order_id = $request['id'];
        $status = $request['status'];
        $notes = $request['notes'];
        
        $post = jd_get_order_by_id($order_id);
        if (!$post) {
            return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
        }
        
        $old_status = get_post_meta($post->ID, '_status', true);
        update_post_meta($post->ID, '_status', $status);
        
        // Set completion date if completed
        if ($status === 'completed' && $old_status !== 'completed') {
            update_post_meta($post->ID, '_completed_date', current_time('mysql'));
            
            // Update transcriber statistics
            $assigned_to = get_post_meta($post->ID, '_assigned_to', true);
            if ($assigned_to) {
                $this->update_transcriber_stats($assigned_to, 'completed_orders', 1);
            }
            
            // Send completion notification to client
            $this->send_completion_notification($post);
        }
        
        // Add timeline entry
        $current_user = wp_get_current_user();
        $this->add_timeline_entry(
            $post->ID, 
            "Status Changed to {$status}", 
            $current_user->user_login, 
            $notes ?: "Status updated from {$old_status} to {$status}"
        );
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Order status updated successfully',
            'data' => array(
                'orderId' => $order_id,
                'status' => $status,
                'completedDate' => $status === 'completed' ? current_time('c') : null,
            ),
        ), 200);
    }
    
    /**
     * Get dashboard statistics
     */
    public function get_dashboard_stats($request) {
        $args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        );
        
        $all_orders = get_posts($args);
        
        $stats = array(
            'totalOrders' => count($all_orders),
            'pendingOrders' => 0,
            'inProgressOrders' => 0,
            'completedOrders' => 0,
            'overdueOrders' => 0,
            'totalRevenue' => 0,
            'recentOrders' => array(),
        );
        
        $current_time = current_time('timestamp');
        
        foreach ($all_orders as $order) {
            $status = get_post_meta($order->ID, '_status', true);
            $due_date = get_post_meta($order->ID, '_due_date', true);
            $actual_cost = get_post_meta($order->ID, '_actual_cost', true);
            
            // Count by status
            switch ($status) {
                case 'pending':
                    $stats['pendingOrders']++;
                    break;
                case 'in-progress':
                    $stats['inProgressOrders']++;
                    break;
                case 'completed':
                    $stats['completedOrders']++;
                    if ($actual_cost) {
                        $stats['totalRevenue'] += floatval($actual_cost);
                    }
                    break;
            }
            
            // Check if overdue
            if (in_array($status, array('pending', 'in-progress')) && $due_date) {
                $due_timestamp = strtotime($due_date);
                if ($due_timestamp < $current_time) {
                    $stats['overdueOrders']++;
                }
            }
        }
        
        // Get recent orders
        $recent_args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => 5,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        $recent_orders = get_posts($recent_args);
        foreach ($recent_orders as $order) {
            $stats['recentOrders'][] = $this->format_order_data($order);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $stats,
        ), 200);
    }
    
    /**
     * Helper Functions
     */
    
    private function format_order_data($post) {
        return array(
            'id' => $post->ID,
            'orderId' => get_post_meta($post->ID, '_order_id', true),
            'clientName' => get_post_meta($post->ID, '_client_name', true),
            'clientEmail' => get_post_meta($post->ID, '_client_email', true),
            'clientPhone' => get_post_meta($post->ID, '_client_phone', true),
            'serviceType' => get_post_meta($post->ID, '_service_type', true),
            'turnaround' => get_post_meta($post->ID, '_turnaround', true),
            'estimatedCost' => get_post_meta($post->ID, '_estimated_cost', true),
            'actualCost' => get_post_meta($post->ID, '_actual_cost', true),
            'status' => get_post_meta($post->ID, '_status', true),
            'priority' => get_post_meta($post->ID, '_priority', true),
            'assignedTo' => get_post_meta($post->ID, '_assigned_to', true),
            'assignedTranscriberName' => get_post_meta($post->ID, '_assigned_transcriber_name', true),
            'instructions' => $post->post_content,
            'dueDate' => get_post_meta($post->ID, '_due_date', true),
            'completedDate' => get_post_meta($post->ID, '_completed_date', true),
            'createdAt' => $post->post_date,
        );
    }
    
    private function add_timeline_entry($order_id, $action, $performed_by, $notes = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_order_timeline';
        
        $wpdb->insert(
            $table_name,
            array(
                'order_id' => $order_id,
                'action' => $action,
                'performed_by' => $performed_by,
                'notes' => $notes,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
    }
    
    private function get_order_timeline($order_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_order_timeline';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE order_id = %d ORDER BY created_at DESC",
            $order_id
        ), ARRAY_A);
    }
    
    private function get_transcriber_by_id($transcriber_id) {
        $posts = get_posts(array(
            'post_type' => 'jd_transcriber',
            'meta_query' => array(
                array(
                    'key' => '_transcriber_id',
                    'value' => $transcriber_id,
                    'compare' => '=',
                ),
            ),
            'posts_per_page' => 1,
        ));
        
        return !empty($posts) ? $posts[0] : null;
    }
    
    private function update_transcriber_stats($transcriber_id, $field, $increment) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_transcriber_stats';
        
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE transcriber_id = %d",
            $transcriber_id
        ));
        
        if ($existing) {
            $wpdb->update(
                $table_name,
                array($field => $existing->$field + $increment),
                array('transcriber_id' => $transcriber_id),
                array('%d'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $table_name,
                array(
                    'transcriber_id' => $transcriber_id,
                    $field => $increment,
                ),
                array('%d', '%d')
            );
        }
    }
    
    private function send_new_order_notification($order_id, $order_data) {
        $admin_email = get_option('admin_email');
        $subject = 'New Order Received - ' . $order_id;
        
        $message = sprintf(
            '<h2>New Order Received</h2>
            <p><strong>Order ID:</strong> %s</p>
            <p><strong>Client:</strong> %s (%s)</p>
            <p><strong>Service:</strong> %s</p>
            <p><strong>Turnaround:</strong> %s</p>
            <p><strong>Instructions:</strong> %s</p>
            <p>Please check the admin panel for full details.</p>',
            $order_id,
            $order_data['clientName'],
            $order_data['clientEmail'],
            $order_data['serviceType'],
            $order_data['turnaround'],
            $order_data['instructions'] ?? 'None'
        );
        
        jd_send_email_notification($admin_email, $subject, $message);
    }
    
    private function send_assignment_notification($order_post, $transcriber_post) {
        $transcriber_email = get_post_meta($transcriber_post->ID, '_email', true);
        $transcriber_name = get_post_meta($transcriber_post->ID, '_name', true);
        $order_id = get_post_meta($order_post->ID, '_order_id', true);
        
        if (!$transcriber_email) return;
        
        $subject = 'New Order Assignment - ' . $order_id;
        
        $message = sprintf(
            '<h2>Order Assignment</h2>
            <p>Hello %s,</p>
            <p>You have been assigned a new order:</p>
            <p><strong>Order ID:</strong> %s</p>
            <p><strong>Client:</strong> %s</p>
            <p><strong>Service:</strong> %s</p>
            <p><strong>Due Date:</strong> %s</p>
            <p>Please log in to the system to view full details.</p>',
            $transcriber_name,
            $order_id,
            get_post_meta($order_post->ID, '_client_name', true),
            get_post_meta($order_post->ID, '_service_type', true),
            get_post_meta($order_post->ID, '_due_date', true)
        );
        
        jd_send_email_notification($transcriber_email, $subject, $message);
    }
    
    private function send_completion_notification($order_post) {
        $client_email = get_post_meta($order_post->ID, '_client_email', true);
        $client_name = get_post_meta($order_post->ID, '_client_name', true);
        $order_id = get_post_meta($order_post->ID, '_order_id', true);
        
        if (!$client_email) return;
        
        $subject = 'Order Completed - ' . $order_id;
        
        $message = sprintf(
            '<h2>Order Completed</h2>
            <p>Dear %s,</p>
            <p>Your order has been completed:</p>
            <p><strong>Order ID:</strong> %s</p>
            <p><strong>Service:</strong> %s</p>
            <p>Thank you for choosing JD Legal Transcripts!</p>',
            $client_name,
            $order_id,
            get_post_meta($order_post->ID, '_service_type', true)
        );
        
        jd_send_email_notification($client_email, $subject, $message);
    }
    
    public function check_admin_permission($request) {
        return current_user_can('manage_options') || jd_is_admin_user();
    }
}