<?php
/**
 * Careers API Endpoints
 * Replaces Node.js /api/careers routes
 */

class JD_API_Careers {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // GET /api/careers/positions - Get available positions
        register_rest_route($namespace, '/careers/positions', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_positions'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'type' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'location' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'active' => array(
                    'required' => false,
                    'type' => 'boolean',
                    'default' => true,
                ),
            ),
        ));
        
        // POST /api/careers/apply - Submit job application
        register_rest_route($namespace, '/careers/apply', array(
            'methods' => 'POST',
            'callback' => array($this, 'submit_application'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'name' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'phone' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'position' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'experience' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'coverLetter' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'availability' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'expectedSalary' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/careers/applications - Get all applications (admin only)
        register_rest_route($namespace, '/careers/applications', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_applications'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'status' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'position' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 20,
                ),
            ),
        ));
        
        // GET /api/careers/applications/{id} - Get single application
        register_rest_route($namespace, '/careers/applications/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_application'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                ),
            ),
        ));
        
        // PUT /api/careers/applications/{id}/status - Update application status
        register_rest_route($namespace, '/careers/applications/(?P<id>\d+)/status', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_application_status'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                ),
                'status' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'notes' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // POST /api/careers/positions - Create new position (admin only)
        register_rest_route($namespace, '/careers/positions', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_position'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'title' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'description' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'requirements' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'type' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'full-time',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'location' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'remote',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'salaryRange' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'isActive' => array(
                    'required' => false,
                    'type' => 'boolean',
                    'default' => true,
                ),
            ),
        ));
        
        // PUT /api/careers/positions/{id} - Update position
        register_rest_route($namespace, '/careers/positions/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_position'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                ),
            ),
        ));
        
        // DELETE /api/careers/positions/{id} - Delete position
        register_rest_route($namespace, '/careers/positions/(?P<id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_position'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                ),
            ),
        ));
    }
    
    /**
     * Get available positions
     */
    public function get_positions($request) {
        $params = $request->get_params();
        
        $args = array(
            'post_type' => 'jd_job_position',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(),
        );
        
        // Filter by active status
        if ($params['active']) {
            $args['meta_query'][] = array(
                'key' => '_is_active',
                'value' => '1',
                'compare' => '=',
            );
        }
        
        // Filter by type
        if (!empty($params['type'])) {
            $args['meta_query'][] = array(
                'key' => '_job_type',
                'value' => $params['type'],
                'compare' => '=',
            );
        }
        
        // Filter by location
        if (!empty($params['location'])) {
            $args['meta_query'][] = array(
                'key' => '_location',
                'value' => $params['location'],
                'compare' => '=',
            );
        }
        
        $positions = get_posts($args);
        $formatted_positions = array();
        
        foreach ($positions as $position) {
            $formatted_positions[] = $this->format_position_data($position);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $formatted_positions,
        ), 200);
    }
    
    /**
     * Submit job application
     */
    public function submit_application($request) {
        try {
            $params = $request->get_params();
            
            // Check if email already applied for this position recently
            $recent_application = get_posts(array(
                'post_type' => 'jd_job_application',
                'meta_query' => array(
                    array(
                        'key' => '_email',
                        'value' => $params['email'],
                        'compare' => '=',
                    ),
                    array(
                        'key' => '_position',
                        'value' => $params['position'],
                        'compare' => '=',
                    ),
                ),
                'date_query' => array(
                    array(
                        'after' => '30 days ago',
                    ),
                ),
                'posts_per_page' => 1,
            ));
            
            if (!empty($recent_application)) {
                return new WP_Error('duplicate_application', 'You have already applied for this position recently', array('status' => 400));
            }
            
            // Generate application ID
            $application_id = $this->generate_application_id();
            
            // Create application post
            $post_id = wp_insert_post(array(
                'post_title' => sprintf('Application from %s - %s', $params['name'], $params['position']),
                'post_content' => $params['coverLetter'] ?? '',
                'post_status' => 'publish',
                'post_type' => 'jd_job_application',
                'post_author' => 1, // System user
            ));
            
            if (is_wp_error($post_id)) {
                return new WP_Error('application_creation_failed', 'Failed to create application', array('status' => 500));
            }
            
            // Save application metadata
            update_post_meta($post_id, '_application_id', $application_id);
            update_post_meta($post_id, '_name', $params['name']);
            update_post_meta($post_id, '_email', $params['email']);
            update_post_meta($post_id, '_phone', $params['phone'] ?? '');
            update_post_meta($post_id, '_position', $params['position']);
            update_post_meta($post_id, '_experience', $params['experience'] ?? '');
            update_post_meta($post_id, '_availability', $params['availability'] ?? '');
            update_post_meta($post_id, '_expected_salary', $params['expectedSalary'] ?? '');
            update_post_meta($post_id, '_status', 'pending');
            update_post_meta($post_id, '_submitted_at', current_time('mysql'));
            
            // Send confirmation email to applicant
            $this->send_application_confirmation($params);
            
            // Send notification email to admin
            $this->send_new_application_notification($application_id, $params);
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Application submitted successfully',
                'data' => array(
                    'applicationId' => $application_id,
                    'status' => 'pending',
                    'submittedAt' => current_time('c'),
                ),
            ), 201);
            
        } catch (Exception $e) {
            return new WP_Error('application_submission_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get all applications (admin)
     */
    public function get_applications($request) {
        $params = $request->get_params();
        
        $args = array(
            'post_type' => 'jd_job_application',
            'post_status' => 'publish',
            'posts_per_page' => $params['limit'],
            'paged' => $params['page'],
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(),
        );
        
        // Filter by status
        if (!empty($params['status'])) {
            $args['meta_query'][] = array(
                'key' => '_status',
                'value' => $params['status'],
                'compare' => '=',
            );
        }
        
        // Filter by position
        if (!empty($params['position'])) {
            $args['meta_query'][] = array(
                'key' => '_position',
                'value' => $params['position'],
                'compare' => '=',
            );
        }
        
        $query = new WP_Query($args);
        $applications = array();
        
        foreach ($query->posts as $post) {
            $applications[] = $this->format_application_data($post);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $applications,
            'pagination' => array(
                'current' => intval($params['page']),
                'pages' => $query->max_num_pages,
                'total' => $query->found_posts,
            ),
        ), 200);
    }
    
    /**
     * Get single application
     */
    public function get_application($request) {
        $application_id = $request['id'];
        $post = get_post($application_id);
        
        if (!$post || $post->post_type !== 'jd_job_application') {
            return new WP_Error('application_not_found', 'Application not found', array('status' => 404));
        }
        
        $application_data = $this->format_application_data($post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $application_data,
        ), 200);
    }
    
    /**
     * Update application status
     */
    public function update_application_status($request) {
        $application_id = $request['id'];
        $status = $request['status'];
        $notes = $request['notes'];
        
        $post = get_post($application_id);
        
        if (!$post || $post->post_type !== 'jd_job_application') {
            return new WP_Error('application_not_found', 'Application not found', array('status' => 404));
        }
        
        $old_status = get_post_meta($post->ID, '_status', true);
        
        // Update status
        update_post_meta($post->ID, '_status', $status);
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        
        if ($notes) {
            update_post_meta($post->ID, '_admin_notes', $notes);
        }
        
        // Send status update email to applicant
        $this->send_status_update_email($post, $status, $old_status);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Application status updated successfully',
            'data' => array(
                'applicationId' => get_post_meta($post->ID, '_application_id', true),
                'status' => $status,
                'updatedAt' => current_time('c'),
            ),
        ), 200);
    }
    
    /**
     * Create new position
     */
    public function create_position($request) {
        $params = $request->get_params();
        
        // Create position post
        $post_id = wp_insert_post(array(
            'post_title' => $params['title'],
            'post_content' => $params['description'],
            'post_status' => 'publish',
            'post_type' => 'jd_job_position',
            'post_author' => get_current_user_id(),
        ));
        
        if (is_wp_error($post_id)) {
            return new WP_Error('position_creation_failed', 'Failed to create position', array('status' => 500));
        }
        
        // Save position metadata
        update_post_meta($post_id, '_requirements', $params['requirements'] ?? '');
        update_post_meta($post_id, '_job_type', $params['type']);
        update_post_meta($post_id, '_location', $params['location']);
        update_post_meta($post_id, '_salary_range', $params['salaryRange'] ?? '');
        update_post_meta($post_id, '_is_active', $params['isActive'] ? '1' : '0');
        update_post_meta($post_id, '_created_at', current_time('mysql'));
        
        $position_data = $this->format_position_data(get_post($post_id));
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Position created successfully',
            'data' => $position_data,
        ), 201);
    }
    
    /**
     * Update position
     */
    public function update_position($request) {
        $position_id = $request['id'];
        $update_data = $request->get_json_params();
        
        $post = get_post($position_id);
        
        if (!$post || $post->post_type !== 'jd_job_position') {
            return new WP_Error('position_not_found', 'Position not found', array('status' => 404));
        }
        
        // Update post
        if (isset($update_data['title']) || isset($update_data['description'])) {
            wp_update_post(array(
                'ID' => $post->ID,
                'post_title' => $update_data['title'] ?? $post->post_title,
                'post_content' => $update_data['description'] ?? $post->post_content,
            ));
        }
        
        // Update meta fields
        $meta_fields = array(
            'requirements' => '_requirements',
            'type' => '_job_type',
            'location' => '_location',
            'salaryRange' => '_salary_range',
        );
        
        foreach ($meta_fields as $field => $meta_key) {
            if (isset($update_data[$field])) {
                update_post_meta($post->ID, $meta_key, $update_data[$field]);
            }
        }
        
        if (isset($update_data['isActive'])) {
            update_post_meta($post->ID, '_is_active', $update_data['isActive'] ? '1' : '0');
        }
        
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        
        $updated_position = $this->format_position_data($post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Position updated successfully',
            'data' => $updated_position,
        ), 200);
    }
    
    /**
     * Delete position
     */
    public function delete_position($request) {
        $position_id = $request['id'];
        $post = get_post($position_id);
        
        if (!$post || $post->post_type !== 'jd_job_position') {
            return new WP_Error('position_not_found', 'Position not found', array('status' => 404));
        }
        
        // Check if there are pending applications
        $pending_applications = get_posts(array(
            'post_type' => 'jd_job_application',
            'meta_query' => array(
                array(
                    'key' => '_position',
                    'value' => $post->post_title,
                    'compare' => '=',
                ),
                array(
                    'key' => '_status',
                    'value' => 'pending',
                    'compare' => '=',
                ),
            ),
            'posts_per_page' => 1,
        ));
        
        if (!empty($pending_applications)) {
            return new WP_Error('position_has_pending_applications', 'Cannot delete position with pending applications', array('status' => 400));
        }
        
        wp_delete_post($post->ID, true);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Position deleted successfully',
        ), 200);
    }
    
    /**
     * Helper Functions
     */
    
    private function format_position_data($post) {
        return array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'description' => $post->post_content,
            'requirements' => get_post_meta($post->ID, '_requirements', true),
            'type' => get_post_meta($post->ID, '_job_type', true),
            'location' => get_post_meta($post->ID, '_location', true),
            'salaryRange' => get_post_meta($post->ID, '_salary_range', true),
            'isActive' => get_post_meta($post->ID, '_is_active', true) === '1',
            'createdAt' => get_post_meta($post->ID, '_created_at', true) ?: $post->post_date,
            'updatedAt' => get_post_meta($post->ID, '_updated_at', true),
        );
    }
    
    private function format_application_data($post) {
        return array(
            'id' => $post->ID,
            'applicationId' => get_post_meta($post->ID, '_application_id', true),
            'name' => get_post_meta($post->ID, '_name', true),
            'email' => get_post_meta($post->ID, '_email', true),
            'phone' => get_post_meta($post->ID, '_phone', true),
            'position' => get_post_meta($post->ID, '_position', true),
            'experience' => get_post_meta($post->ID, '_experience', true),
            'coverLetter' => $post->post_content,
            'availability' => get_post_meta($post->ID, '_availability', true),
            'expectedSalary' => get_post_meta($post->ID, '_expected_salary', true),
            'status' => get_post_meta($post->ID, '_status', true),
            'adminNotes' => get_post_meta($post->ID, '_admin_notes', true),
            'submittedAt' => get_post_meta($post->ID, '_submitted_at', true) ?: $post->post_date,
            'updatedAt' => get_post_meta($post->ID, '_updated_at', true),
        );
    }
    
    private function generate_application_id() {
        return 'APP' . date('Ymd') . '-' . wp_rand(1000, 9999);
    }
    
    private function send_application_confirmation($application_data) {
        $subject = 'Application Received - JD Legal Transcripts';
        
        $message = sprintf(
            '<h2>Application Received</h2>
            <p>Dear %s,</p>
            <p>Thank you for your interest in the <strong>%s</strong> position at JD Legal Transcripts.</p>
            <p>We have received your application and will review it carefully. We will contact you within 5-7 business days regarding the next steps.</p>
            <p>If you have any questions, please feel free to contact us.</p>
            <p>Best regards,<br>JD Legal Transcripts Team</p>',
            $application_data['name'],
            $application_data['position']
        );
        
        jd_send_email_notification($application_data['email'], $subject, $message);
    }
    
    private function send_new_application_notification($application_id, $application_data) {
        $admin_email = get_option('admin_email');
        $subject = 'New Job Application Received - ' . $application_id;
        
        $message = sprintf(
            '<h2>New Job Application</h2>
            <p><strong>Application ID:</strong> %s</p>
            <p><strong>Position:</strong> %s</p>
            <p><strong>Applicant:</strong> %s (%s)</p>
            <p><strong>Phone:</strong> %s</p>
            <p><strong>Experience:</strong> %s</p>
            <p>Please check the admin panel for full details.</p>',
            $application_id,
            $application_data['position'],
            $application_data['name'],
            $application_data['email'],
            $application_data['phone'] ?? 'Not provided',
            $application_data['experience'] ?? 'Not provided'
        );
        
        jd_send_email_notification($admin_email, $subject, $message);
    }
    
    private function send_status_update_email($post, $new_status, $old_status) {
        $applicant_email = get_post_meta($post->ID, '_email', true);
        $applicant_name = get_post_meta($post->ID, '_name', true);
        $position = get_post_meta($post->ID, '_position', true);
        
        if (!$applicant_email) return;
        
        $status_messages = array(
            'under_review' => 'Your application is currently under review.',
            'interview' => 'Congratulations! We would like to schedule an interview with you.',
            'accepted' => 'Congratulations! Your application has been accepted.',
            'rejected' => 'Thank you for your interest. Unfortunately, we have decided to move forward with other candidates.',
        );
        
        $status_message = $status_messages[$new_status] ?? 'Your application status has been updated.';
        
        $subject = 'Application Status Update - JD Legal Transcripts';
        
        $message = sprintf(
            '<h2>Application Status Update</h2>
            <p>Dear %s,</p>
            <p>We wanted to update you on the status of your application for the <strong>%s</strong> position.</p>
            <p><strong>Status:</strong> %s</p>
            <p>%s</p>
            <p>If you have any questions, please feel free to contact us.</p>
            <p>Best regards,<br>JD Legal Transcripts Team</p>',
            $applicant_name,
            $position,
            ucwords(str_replace('_', ' ', $new_status)),
            $status_message
        );
        
        jd_send_email_notification($applicant_email, $subject, $message);
    }
    
    public function check_admin_permission($request) {
        return current_user_can('manage_options') || jd_is_admin_user();
    }
}