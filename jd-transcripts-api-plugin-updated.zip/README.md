# JD Transcripts API Backend Plugin

A comprehensive WordPress plugin that provides a complete backend API for the JD Legal Transcripts application, replacing the Node.js backend while maintaining full compatibility with the React frontend.

## Features

- **Complete REST API**: All endpoints from the original Node.js backend
- **Custom Post Types**: Orders, Transcribers, Job Applications, Positions, Contact Forms, etc.
- **Authentication System**: WordPress-based authentication with session management
- **Email Integration**: Built-in WordPress email functionality
- **Admin Interface**: Full WordPress admin integration
- **CORS Support**: Configured for Netlify frontend integration

## Installation

1. **Upload Plugin**
   - Copy the `jd-transcripts-api` folder to `wp-content/plugins/`
   - Or upload as a ZIP file through WordPress admin

2. **Activate Plugin**
   - Go to Plugins → Installed Plugins
   - Find "JD Transcripts API Backend"
   - Click "Activate"

3. **Run Setup**
   - Go to Tools → JD API Setup
   - Configure your settings
   - Click "Run Setup"

## API Endpoints

Base URL: `https://yourdomain.com/wp-json/jd-api/v1`

### Authentication
- `POST /auth/login` - Admin login
- `POST /auth/logout` - Admin logout
- `GET /auth/me` - Get current user
- `POST /auth/register` - Register admin user
- `PUT /auth/change-password` - Change password
- `POST /auth/forgot-password` - Password reset

### Orders
- `POST /orders` - Create order
- `GET /orders` - Get orders (admin)
- `GET /orders/{id}` - Get single order
- `PUT /orders/{id}/assign` - Assign to transcriber
- `PUT /orders/{id}/status` - Update status
- `GET /orders/stats/dashboard` - Dashboard stats

### Admin
- `GET /admin/dashboard` - Dashboard stats
- `GET /admin/orders` - Get orders with filters
- `PATCH /admin/orders/{id}` - Update order
- `POST /admin/orders/{id}/assign` - Assign order
- `GET /admin/users` - Get users
- `GET /admin/analytics` - Analytics data
- `GET /admin/settings` - System settings
- `PUT /admin/settings` - Update settings

### Transcribers
- `GET /transcribers` - Get transcribers
- `POST /transcribers` - Create transcriber
- `GET /transcribers/{id}` - Get single transcriber
- `PUT /transcribers/{id}` - Update transcriber
- `DELETE /transcribers/{id}` - Delete transcriber
- `DELETE /transcribers/clear` - Clear all
- `GET /transcribers/{id}/stats` - Get stats
- `PUT /transcribers/{id}/availability` - Update availability

### Careers
- `GET /careers/positions` - Get positions
- `POST /careers/apply` - Submit application
- `GET /careers/applications` - Get applications (admin)
- `GET /careers/applications/{id}` - Get application
- `PUT /careers/applications/{id}/status` - Update status
- `POST /careers/positions` - Create position
- `PUT /careers/positions/{id}` - Update position
- `DELETE /careers/positions/{id}` - Delete position

### Email
- `POST /email/contact` - Contact form
- `POST /email/quote` - Quote request
- `POST /email/newsletter` - Newsletter signup
- `POST /email/send-custom` - Send custom email (admin)
- `GET /email/templates` - Get templates
- `POST /email/test` - Test email config

## Configuration

### Frontend Integration

Update your React frontend API base URL:

```javascript
const API_BASE = 'https://yourdomain.com/wp-json/jd-api/v1';
```

### CORS Configuration

The plugin automatically configures CORS for your frontend domain. Update the domain in the plugin if needed:

```php
header('Access-Control-Allow-Origin: https://your-netlify-domain.netlify.app');
```

### Email Settings

Configure WordPress email settings:
- Go to Settings → General
- Set your site email address
- Consider using an SMTP plugin for better email delivery

## Custom Post Types

The plugin creates these custom post types:

- **Orders** (`jd_order`) - Customer orders
- **Transcribers** (`jd_transcriber`) - Transcriber profiles
- **Job Applications** (`jd_job_application`) - Job applications
- **Job Positions** (`jd_job_position`) - Available positions
- **Contact Forms** (`jd_contact_form`) - Contact submissions
- **Quote Requests** (`jd_quote_request`) - Quote requests
- **Newsletter Subscriptions** (`jd_newsletter_sub`) - Newsletter signups
- **Email Logs** (`jd_email_log`) - Email sending logs

## User Roles

The plugin creates these custom roles:

- **Transcriber** - Can view assigned orders
- **JD Manager** - Can manage orders and transcribers
- **Administrator** - Full access

## Database Tables

Additional tables created:

- `wp_jd_order_timeline` - Order activity timeline
- `wp_jd_transcriber_stats` - Transcriber statistics

## Requirements

- WordPress 5.0+
- PHP 7.4+
- MySQL 5.6+
- Pretty permalinks enabled

## Support

For support and customization:

1. Check the WordPress admin for any error messages
2. Enable WordPress debug logging
3. Check server error logs
4. Verify permalink settings (Settings → Permalinks)

## Security

The plugin includes:

- Nonce verification for all forms
- Capability checks for admin functions
- Data sanitization and validation
- CORS configuration
- Session-based authentication

## Performance

For optimal performance:

- Use a caching plugin
- Enable object caching if available
- Optimize database regularly
- Use a CDN for static assets

## Changelog

### Version 1.0.0
- Initial release
- Complete API endpoint coverage
- WordPress admin integration
- Email functionality
- Authentication system
- Custom post types and roles

## License

GPL v2 or later