<?php
/**
 * Installation and Setup Script for JD Transcripts API Plugin
 * 
 * This script helps with the initial setup and configuration
 * Run this once after plugin activation
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Installation and Setup Class
 */
class JD_API_Installer {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_setup_page'));
        add_action('wp_ajax_jd_run_setup', array($this, 'run_setup'));
    }
    
    /**
     * Add setup page to admin menu
     */
    public function add_setup_page() {
        add_management_page(
            'JD API Setup',
            'JD API Setup',
            'manage_options',
            'jd-api-setup',
            array($this, 'setup_page')
        );
    }
    
    /**
     * Setup page content
     */
    public function setup_page() {
        ?>
        <div class="wrap">
            <h1>JD Transcripts API Setup</h1>
            
            <div class="notice notice-info">
                <p><strong>Welcome!</strong> This setup wizard will help you configure the JD Transcripts API plugin.</p>
            </div>
            
            <div class="card">
                <h2>Setup Steps</h2>
                <ol>
                    <li>Create database tables</li>
                    <li>Set up default admin user</li>
                    <li>Configure default settings</li>
                    <li>Create sample data (optional)</li>
                    <li>Test API endpoints</li>
                </ol>
            </div>
            
            <div class="card">
                <h2>Configuration</h2>
                <form id="jd-setup-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Frontend URL</th>
                            <td>
                                <input type="url" name="frontend_url" value="https://sensational-tartufo-6888eb.netlify.app" class="regular-text" />
                                <p class="description">Your Netlify frontend URL for CORS configuration</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Company Name</th>
                            <td>
                                <input type="text" name="company_name" value="JD Legal Transcripts" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Company Email</th>
                            <td>
                                <input type="email" name="company_email" value="<?php echo get_option('admin_email'); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Create Sample Data</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="create_sample_data" value="1" checked />
                                    Create sample orders, transcribers, and positions for testing
                                </label>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="button" id="run-setup" class="button button-primary button-large">
                            Run Setup
                        </button>
                    </p>
                </form>
            </div>
            
            <div id="setup-progress" style="display: none;">
                <div class="card">
                    <h2>Setup Progress</h2>
                    <div id="progress-log"></div>
                </div>
            </div>
            
            <div id="setup-complete" style="display: none;">
                <div class="notice notice-success">
                    <p><strong>Setup Complete!</strong> Your JD Transcripts API is ready to use.</p>
                </div>
                
                <div class="card">
                    <h2>Next Steps</h2>
                    <ol>
                        <li>Update your frontend configuration to use: <code><?php echo home_url('/wp-json/jd-api/v1'); ?></code></li>
                        <li>Test the API endpoints using the links below</li>
                        <li>Configure your email settings if needed</li>
                    </ol>
                </div>
                
                <div class="card">
                    <h2>API Endpoints</h2>
                    <p>Your API base URL: <strong><?php echo home_url('/wp-json/jd-api/v1'); ?></strong></p>
                    
                    <h3>Test Links</h3>
                    <ul>
                        <li><a href="<?php echo home_url('/wp-json/jd-api/v1/transcribers'); ?>" target="_blank">Get Transcribers</a></li>
                        <li><a href="<?php echo home_url('/wp-json/jd-api/v1/careers/positions'); ?>" target="_blank">Get Job Positions</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#run-setup').click(function() {
                var button = $(this);
                var form = $('#jd-setup-form');
                var progress = $('#setup-progress');
                var complete = $('#setup-complete');
                var log = $('#progress-log');
                
                button.prop('disabled', true).text('Running Setup...');
                progress.show();
                log.html('<p>Starting setup...</p>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'jd_run_setup',
                        nonce: '<?php echo wp_create_nonce('jd_setup_nonce'); ?>',
                        frontend_url: $('input[name="frontend_url"]').val(),
                        company_name: $('input[name="company_name"]').val(),
                        company_email: $('input[name="company_email"]').val(),
                        create_sample_data: $('input[name="create_sample_data"]').is(':checked') ? 1 : 0
                    },
                    success: function(response) {
                        if (response.success) {
                            log.html(response.data.log);
                            complete.show();
                            form.hide();
                        } else {
                            log.html('<p style="color: red;">Setup failed: ' + response.data + '</p>');
                        }
                        button.prop('disabled', false).text('Run Setup');
                    },
                    error: function() {
                        log.html('<p style="color: red;">Setup failed due to an error.</p>');
                        button.prop('disabled', false).text('Run Setup');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Run the setup process
     */
    public function run_setup() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'jd_setup_nonce')) {
            wp_die('Security check failed');
        }
        
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $log = array();
        $log[] = '<p>✓ Starting JD Transcripts API setup...</p>';
        
        try {
            // Save configuration
            update_option('jd_frontend_url', sanitize_url($_POST['frontend_url']));
            update_option('jd_company_name', sanitize_text_field($_POST['company_name']));
            update_option('jd_company_email', sanitize_email($_POST['company_email']));
            $log[] = '<p>✓ Configuration saved</p>';
            
            // Create database tables (already done in plugin activation)
            $log[] = '<p>✓ Database tables verified</p>';
            
            // Create sample data if requested
            if (!empty($_POST['create_sample_data'])) {
                $this->create_sample_data();
                $log[] = '<p>✓ Sample data created</p>';
            }
            
            // Test API endpoints
            $test_results = $this->test_api_endpoints();
            if ($test_results) {
                $log[] = '<p>✓ API endpoints tested successfully</p>';
            } else {
                $log[] = '<p>⚠ API endpoint test had some issues (check permalink settings)</p>';
            }
            
            // Flush rewrite rules
            flush_rewrite_rules();
            $log[] = '<p>✓ Rewrite rules flushed</p>';
            
            $log[] = '<p><strong>✓ Setup completed successfully!</strong></p>';
            
            wp_send_json_success(array('log' => implode('', $log)));
            
        } catch (Exception $e) {
            $log[] = '<p style="color: red;">✗ Error: ' . $e->getMessage() . '</p>';
            wp_send_json_error(implode('', $log));
        }
    }
    
    /**
     * Create sample data for testing
     */
    private function create_sample_data() {
        // Create sample transcribers
        $transcribers = array(
            array(
                'name' => 'Sarah Johnson',
                'email' => 'sarah@example.com',
                'specialization' => 'Legal Transcription',
                'hourlyRate' => 25,
                'availability' => 'available'
            ),
            array(
                'name' => 'Michael Chen',
                'email' => 'michael@example.com',
                'specialization' => 'Medical Transcription',
                'hourlyRate' => 30,
                'availability' => 'available'
            ),
            array(
                'name' => 'Emily Rodriguez',
                'email' => 'emily@example.com',
                'specialization' => 'Academic & Interview',
                'hourlyRate' => 20,
                'availability' => 'busy'
            )
        );
        
        foreach ($transcribers as $transcriber) {
            $transcriber_id = 'TR' . date('ymd') . wp_rand(100, 999);
            
            $post_id = wp_insert_post(array(
                'post_title' => $transcriber['name'] . ' - ' . $transcriber_id,
                'post_content' => 'Sample transcriber with experience in ' . $transcriber['specialization'],
                'post_status' => 'publish',
                'post_type' => 'jd_transcriber',
                'post_author' => 1,
            ));
            
            if (!is_wp_error($post_id)) {
                update_post_meta($post_id, '_transcriber_id', $transcriber_id);
                update_post_meta($post_id, '_name', $transcriber['name']);
                update_post_meta($post_id, '_email', $transcriber['email']);
                update_post_meta($post_id, '_specialization', $transcriber['specialization']);
                update_post_meta($post_id, '_hourly_rate', $transcriber['hourlyRate']);
                update_post_meta($post_id, '_availability', $transcriber['availability']);
                update_post_meta($post_id, '_created_at', current_time('mysql'));
                update_post_meta($post_id, '_is_active', true);
            }
        }
        
        // Create sample job positions
        $positions = array(
            array(
                'title' => 'Legal Transcriptionist',
                'description' => 'We are seeking an experienced legal transcriptionist to join our team.',
                'type' => 'full-time',
                'location' => 'remote',
                'requirements' => 'Minimum 2 years experience in legal transcription'
            ),
            array(
                'title' => 'Medical Transcriptionist',
                'description' => 'Join our medical transcription team and work with healthcare professionals.',
                'type' => 'part-time',
                'location' => 'remote',
                'requirements' => 'Medical transcription certification required'
            )
        );
        
        foreach ($positions as $position) {
            $post_id = wp_insert_post(array(
                'post_title' => $position['title'],
                'post_content' => $position['description'],
                'post_status' => 'publish',
                'post_type' => 'jd_job_position',
                'post_author' => 1,
            ));
            
            if (!is_wp_error($post_id)) {
                update_post_meta($post_id, '_requirements', $position['requirements']);
                update_post_meta($post_id, '_job_type', $position['type']);
                update_post_meta($post_id, '_location', $position['location']);
                update_post_meta($post_id, '_is_active', '1');
                update_post_meta($post_id, '_created_at', current_time('mysql'));
            }
        }
        
        // Create sample orders
        $orders = array(
            array(
                'clientName' => 'John Smith',
                'clientEmail' => 'john.smith@example.com',
                'serviceType' => 'Legal Transcription',
                'turnaround' => '24h',
                'status' => 'pending',
                'estimatedCost' => '$150'
            ),
            array(
                'clientName' => 'Jane Doe',
                'clientEmail' => 'jane.doe@example.com',
                'serviceType' => 'Medical Transcription',
                'turnaround' => '48h',
                'status' => 'in-progress',
                'estimatedCost' => '$200'
            )
        );
        
        foreach ($orders as $order) {
            $order_id = 'JD' . date('Ymd') . '-' . wp_rand(1000, 9999);
            
            $post_id = wp_insert_post(array(
                'post_title' => 'Order from ' . $order['clientName'] . ' - ' . $order_id,
                'post_content' => 'Sample order for testing purposes',
                'post_status' => 'publish',
                'post_type' => 'jd_order',
                'post_author' => 1,
            ));
            
            if (!is_wp_error($post_id)) {
                update_post_meta($post_id, '_order_id', $order_id);
                update_post_meta($post_id, '_client_name', $order['clientName']);
                update_post_meta($post_id, '_client_email', $order['clientEmail']);
                update_post_meta($post_id, '_service_type', $order['serviceType']);
                update_post_meta($post_id, '_turnaround', $order['turnaround']);
                update_post_meta($post_id, '_estimated_cost', $order['estimatedCost']);
                update_post_meta($post_id, '_status', $order['status']);
                update_post_meta($post_id, '_created_at', current_time('mysql'));
                
                $due_date = new DateTime();
                $due_date->add(new DateInterval('PT24H'));
                update_post_meta($post_id, '_due_date', $due_date->format('Y-m-d H:i:s'));
            }
        }
    }
    
    /**
     * Test API endpoints
     */
    private function test_api_endpoints() {
        $base_url = home_url('/wp-json/jd-api/v1');
        
        // Test transcribers endpoint
        $response = wp_remote_get($base_url . '/transcribers');
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        return $status_code === 200;
    }
}

// Initialize the installer
new JD_API_Installer();