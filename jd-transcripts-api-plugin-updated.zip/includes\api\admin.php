<?php
/**
 * Admin API Endpoints
 * Replaces Node.js /api/admin routes
 */

class JD_API_Admin {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // GET /api/admin/dashboard - Get admin dashboard stats
        register_rest_route($namespace, '/admin/dashboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_dashboard_stats'),
            'permission_callback' => array($this, 'check_admin_permission'),
        ));
        
        // GET /api/admin/orders - Get all orders with filtering and pagination
        register_rest_route($namespace, '/admin/orders', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_orders'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'status' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'serviceType' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'clientEmail' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 20,
                ),
                'sortBy' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'createdAt',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'sortOrder' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'desc',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PATCH /api/admin/orders/{id} - Update order (admin)
        register_rest_route($namespace, '/admin/orders/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'PATCH',
            'callback' => array($this, 'update_admin_order'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // POST /api/admin/orders/{id}/assign - Assign order to transcriber
        register_rest_route($namespace, '/admin/orders/(?P<id>[a-zA-Z0-9-]+)/assign', array(
            'methods' => 'POST',
            'callback' => array($this, 'assign_admin_order'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'transcriberId' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'transcriberName' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/admin/users - Get all users
        register_rest_route($namespace, '/admin/users', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_users'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 20,
                ),
                'role' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'isActive' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/admin/analytics - Get analytics data
        register_rest_route($namespace, '/admin/analytics', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_analytics'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'period' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => '30d',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // GET /api/admin/reports - Generate reports
        register_rest_route($namespace, '/admin/reports', array(
            'methods' => 'GET',
            'callback' => array($this, 'generate_admin_reports'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'type' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'startDate' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'endDate' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PUT /api/admin/settings - Update system settings
        register_rest_route($namespace, '/admin/settings', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_admin_settings'),
            'permission_callback' => array($this, 'check_super_admin_permission'),
        ));
        
        // GET /api/admin/settings - Get system settings
        register_rest_route($namespace, '/admin/settings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_settings'),
            'permission_callback' => array($this, 'check_admin_permission'),
        ));
    }
    
    /**
     * Get admin dashboard stats
     */
    public function get_dashboard_stats($request) {
        try {
            $stats = array(
                'totalOrders' => 0,
                'pendingOrders' => 0,
                'inProgressOrders' => 0,
                'processingOrders' => 0, // Alias for inProgressOrders
                'completedOrders' => 0,
                'totalRevenue' => 0,
                'recentOrders' => array(),
            );
            
            // Get all orders
            $args = array(
                'post_type' => 'jd_order',
                'post_status' => 'publish',
                'posts_per_page' => -1,
            );
            
            $all_orders = get_posts($args);
            $stats['totalOrders'] = count($all_orders);
            
            // Count by status and calculate revenue
            foreach ($all_orders as $order) {
                $status = get_post_meta($order->ID, '_status', true);
                $actual_cost = get_post_meta($order->ID, '_actual_cost', true);
                
                switch ($status) {
                    case 'pending':
                        $stats['pendingOrders']++;
                        break;
                    case 'in-progress':
                        $stats['inProgressOrders']++;
                        $stats['processingOrders']++; // Alias
                        break;
                    case 'completed':
                        $stats['completedOrders']++;
                        if ($actual_cost) {
                            $stats['totalRevenue'] += floatval(str_replace('$', '', $actual_cost));
                        }
                        break;
                }
            }
            
            // Get recent orders
            $recent_args = array(
                'post_type' => 'jd_order',
                'post_status' => 'publish',
                'posts_per_page' => 5,
                'orderby' => 'date',
                'order' => 'DESC',
            );
            
            $recent_orders = get_posts($recent_args);
            foreach ($recent_orders as $order) {
                $stats['recentOrders'][] = $this->format_order_data($order);
            }
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Dashboard stats retrieved successfully',
                'data' => $stats,
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('dashboard_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get all orders with filtering and pagination (admin)
     */
    public function get_admin_orders($request) {
        $params = $request->get_params();
        
        $args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => $params['limit'],
            'paged' => $params['page'],
            'meta_query' => array(),
        );
        
        // Set ordering
        switch ($params['sortBy']) {
            case 'createdAt':
                $args['orderby'] = 'date';
                break;
            case 'status':
                $args['orderby'] = 'meta_value';
                $args['meta_key'] = '_status';
                break;
            case 'clientName':
                $args['orderby'] = 'meta_value';
                $args['meta_key'] = '_client_name';
                break;
            default:
                $args['orderby'] = 'date';
        }
        
        $args['order'] = strtoupper($params['sortOrder']);
        
        // Filter by status
        if (!empty($params['status'])) {
            $args['meta_query'][] = array(
                'key' => '_status',
                'value' => $params['status'],
                'compare' => '=',
            );
        }
        
        // Filter by service type
        if (!empty($params['serviceType'])) {
            $args['meta_query'][] = array(
                'key' => '_service_type',
                'value' => $params['serviceType'],
                'compare' => '=',
            );
        }
        
        // Filter by client email
        if (!empty($params['clientEmail'])) {
            $args['meta_query'][] = array(
                'key' => '_client_email',
                'value' => $params['clientEmail'],
                'compare' => 'LIKE',
            );
        }
        
        $query = new WP_Query($args);
        $orders = array();
        
        foreach ($query->posts as $post) {
            $orders[] = $this->format_order_data($post);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Orders retrieved successfully',
            'data' => $orders,
            'pagination' => array(
                'page' => intval($params['page']),
                'limit' => intval($params['limit']),
                'total' => $query->found_posts,
                'pages' => $query->max_num_pages,
            ),
        ), 200);
    }
    
    /**
     * Update order (admin)
     */
    public function update_admin_order($request) {
        $order_id = $request['id'];
        $update_data = $request->get_json_params();
        
        $post = jd_get_order_by_id($order_id);
        if (!$post) {
            return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
        }
        
        $current_user = wp_get_current_user();
        
        // Update post content if instructions provided
        if (isset($update_data['instructions'])) {
            wp_update_post(array(
                'ID' => $post->ID,
                'post_content' => sanitize_textarea_field($update_data['instructions']),
            ));
        }
        
        // Update meta fields
        $meta_fields = array(
            'status' => '_status',
            'priority' => '_priority',
            'estimatedCost' => '_estimated_cost',
            'actualCost' => '_actual_cost',
            'assignedTranscriberName' => '_assigned_transcriber_name',
            'adminNotes' => '_admin_notes',
        );
        
        foreach ($meta_fields as $field => $meta_key) {
            if (isset($update_data[$field])) {
                update_post_meta($post->ID, $meta_key, sanitize_text_field($update_data[$field]));
            }
        }
        
        // Update timestamps
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        update_post_meta($post->ID, '_updated_by', $current_user->user_login);
        
        // Add timeline entry
        $this->add_timeline_entry(
            $post->ID,
            'Order updated by admin',
            $current_user->user_login,
            $update_data['adminNotes'] ?? 'Order updated via admin panel'
        );
        
        // If status changed, add specific timeline entry
        if (isset($update_data['status'])) {
            $this->add_timeline_entry(
                $post->ID,
                "Status changed to {$update_data['status']}",
                $current_user->user_login,
                ''
            );
        }
        
        $updated_order = $this->format_order_data($post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Order updated successfully',
            'data' => $updated_order,
        ), 200);
    }
    
    /**
     * Assign order to transcriber (admin)
     */
    public function assign_admin_order($request) {
        $order_id = $request['id'];
        $transcriber_id = $request['transcriberId'];
        $transcriber_name = $request['transcriberName'];
        
        if (!$transcriber_id && !$transcriber_name) {
            return new WP_Error('missing_transcriber', 'Transcriber ID or name is required', array('status' => 400));
        }
        
        $post = jd_get_order_by_id($order_id);
        if (!$post) {
            return new WP_Error('order_not_found', 'Order not found', array('status' => 404));
        }
        
        $current_user = wp_get_current_user();
        
        // Update order assignment
        if ($transcriber_id) {
            update_post_meta($post->ID, '_assigned_to', $transcriber_id);
        }
        if ($transcriber_name) {
            update_post_meta($post->ID, '_assigned_transcriber_name', $transcriber_name);
        }
        
        update_post_meta($post->ID, '_status', 'in-progress');
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        
        // Add timeline entry
        $this->add_timeline_entry(
            $post->ID,
            "Order assigned to {$transcriber_name}",
            $current_user->user_login,
            'Order assigned for transcription'
        );
        
        $updated_order = $this->format_order_data($post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Order assigned successfully',
            'data' => $updated_order,
        ), 200);
    }
    
    /**
     * Get all users (admin)
     */
    public function get_admin_users($request) {
        $params = $request->get_params();
        
        $args = array(
            'number' => $params['limit'],
            'offset' => ($params['page'] - 1) * $params['limit'],
            'orderby' => 'registered',
            'order' => 'DESC',
        );
        
        // Filter by role
        if (!empty($params['role'])) {
            $args['role'] = $params['role'];
        }
        
        // Filter by active status
        if (!empty($params['isActive'])) {
            $args['meta_query'] = array(
                array(
                    'key' => '_jd_user_active',
                    'value' => $params['isActive'] === 'true' ? '1' : '0',
                    'compare' => '=',
                ),
            );
        }
        
        $user_query = new WP_User_Query($args);
        $users = array();
        
        foreach ($user_query->get_results() as $user) {
            $users[] = array(
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'name' => $user->display_name,
                'role' => $this->get_user_primary_role($user),
                'isActive' => get_user_meta($user->ID, '_jd_user_active', true) !== '0',
                'lastLogin' => get_user_meta($user->ID, '_jd_last_login', true),
                'createdAt' => $user->user_registered,
            );
        }
        
        // Get total count
        $total_args = $args;
        unset($total_args['number'], $total_args['offset']);
        $total_query = new WP_User_Query($total_args);
        $total_users = $total_query->get_total();
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Users retrieved successfully',
            'data' => $users,
            'pagination' => array(
                'page' => intval($params['page']),
                'limit' => intval($params['limit']),
                'total' => $total_users,
                'pages' => ceil($total_users / $params['limit']),
            ),
        ), 200);
    }
    
    /**
     * Get analytics data
     */
    public function get_admin_analytics($request) {
        $period = $request['period'];
        
        // Calculate date range
        $end_date = new DateTime();
        $start_date = new DateTime();
        
        switch ($period) {
            case '7d':
                $start_date->sub(new DateInterval('P7D'));
                break;
            case '30d':
                $start_date->sub(new DateInterval('P30D'));
                break;
            case '90d':
                $start_date->sub(new DateInterval('P90D'));
                break;
            default:
                $start_date->sub(new DateInterval('P30D'));
        }
        
        $analytics = array(
            'ordersByStatus' => array(),
            'ordersByService' => array(),
            'revenueByMonth' => array(),
            'averageCompletionTime' => 0,
            'customerSatisfaction' => 0,
        );
        
        // Get orders in date range
        $args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'date_query' => array(
                array(
                    'after' => $start_date->format('Y-m-d'),
                    'before' => $end_date->format('Y-m-d'),
                    'inclusive' => true,
                ),
            ),
        );
        
        $orders = get_posts($args);
        
        // Analyze orders
        foreach ($orders as $order) {
            $status = get_post_meta($order->ID, '_status', true);
            $service_type = get_post_meta($order->ID, '_service_type', true);
            
            // Count by status
            if (!isset($analytics['ordersByStatus'][$status])) {
                $analytics['ordersByStatus'][$status] = 0;
            }
            $analytics['ordersByStatus'][$status]++;
            
            // Count by service type
            if (!isset($analytics['ordersByService'][$service_type])) {
                $analytics['ordersByService'][$service_type] = 0;
            }
            $analytics['ordersByService'][$service_type]++;
        }
        
        // Calculate revenue by month (simplified)
        $completed_orders = array_filter($orders, function($order) {
            return get_post_meta($order->ID, '_status', true) === 'completed';
        });
        
        $monthly_revenue = array();
        foreach ($completed_orders as $order) {
            $month = date('Y-m', strtotime($order->post_date));
            $cost = get_post_meta($order->ID, '_actual_cost', true);
            
            if (!isset($monthly_revenue[$month])) {
                $monthly_revenue[$month] = 0;
            }
            
            if ($cost) {
                $monthly_revenue[$month] += floatval(str_replace('$', '', $cost));
            }
        }
        
        $analytics['revenueByMonth'] = $monthly_revenue;
        
        // Calculate average completion time (simplified)
        $completion_times = array();
        foreach ($completed_orders as $order) {
            $created = strtotime($order->post_date);
            $completed = get_post_meta($order->ID, '_completed_date', true);
            
            if ($completed) {
                $completed_time = strtotime($completed);
                $completion_times[] = ($completed_time - $created) / 3600; // Hours
            }
        }
        
        if (!empty($completion_times)) {
            $analytics['averageCompletionTime'] = array_sum($completion_times) / count($completion_times);
        }
        
        // Customer satisfaction (placeholder - would need rating system)
        $analytics['customerSatisfaction'] = 4.5;
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $analytics,
        ), 200);
    }
    
    /**
     * Generate admin reports
     */
    public function generate_admin_reports($request) {
        $type = $request['type'];
        $start_date = $request['startDate'] ?? date('Y-m-01'); // First day of current month
        $end_date = $request['endDate'] ?? date('Y-m-d'); // Today
        
        switch ($type) {
            case 'orders':
                return $this->generate_orders_report($start_date, $end_date);
            case 'revenue':
                return $this->generate_revenue_report($start_date, $end_date);
            case 'transcribers':
                return $this->generate_transcribers_report($start_date, $end_date);
            default:
                return new WP_Error('invalid_report_type', 'Invalid report type', array('status' => 400));
        }
    }
    
    /**
     * Update system settings
     */
    public function update_admin_settings($request) {
        $settings = $request->get_json_params();
        
        $allowed_settings = array(
            'company_name',
            'company_email',
            'company_phone',
            'default_turnaround',
            'pricing_rates',
            'email_notifications',
            'system_maintenance',
        );
        
        foreach ($settings as $key => $value) {
            if (in_array($key, $allowed_settings)) {
                update_option('jd_' . $key, $value);
            }
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Settings updated successfully',
        ), 200);
    }
    
    /**
     * Get system settings
     */
    public function get_admin_settings($request) {
        $settings = array(
            'company_name' => get_option('jd_company_name', 'JD Legal Transcripts'),
            'company_email' => get_option('jd_company_email', get_option('admin_email')),
            'company_phone' => get_option('jd_company_phone', ''),
            'default_turnaround' => get_option('jd_default_turnaround', '24h'),
            'pricing_rates' => get_option('jd_pricing_rates', array()),
            'email_notifications' => get_option('jd_email_notifications', true),
            'system_maintenance' => get_option('jd_system_maintenance', false),
        );
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $settings,
        ), 200);
    }
    
    /**
     * Helper Functions
     */
    
    private function format_order_data($post) {
        return array(
            'id' => $post->ID,
            'orderId' => get_post_meta($post->ID, '_order_id', true),
            'clientName' => get_post_meta($post->ID, '_client_name', true),
            'clientEmail' => get_post_meta($post->ID, '_client_email', true),
            'clientPhone' => get_post_meta($post->ID, '_client_phone', true),
            'serviceType' => get_post_meta($post->ID, '_service_type', true),
            'turnaround' => get_post_meta($post->ID, '_turnaround', true),
            'estimatedCost' => get_post_meta($post->ID, '_estimated_cost', true),
            'actualCost' => get_post_meta($post->ID, '_actual_cost', true),
            'status' => get_post_meta($post->ID, '_status', true),
            'priority' => get_post_meta($post->ID, '_priority', true),
            'assignedTo' => get_post_meta($post->ID, '_assigned_to', true),
            'assignedTranscriberName' => get_post_meta($post->ID, '_assigned_transcriber_name', true),
            'instructions' => $post->post_content,
            'dueDate' => get_post_meta($post->ID, '_due_date', true),
            'completedDate' => get_post_meta($post->ID, '_completed_date', true),
            'createdAt' => $post->post_date,
            'updatedAt' => get_post_meta($post->ID, '_updated_at', true),
        );
    }
    
    private function add_timeline_entry($order_id, $action, $performed_by, $notes = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_order_timeline';
        
        $wpdb->insert(
            $table_name,
            array(
                'order_id' => $order_id,
                'action' => $action,
                'performed_by' => $performed_by,
                'notes' => $notes,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
    }
    
    private function get_user_primary_role($user) {
        if (in_array('administrator', $user->roles)) {
            return 'administrator';
        } elseif (in_array('jd_manager', $user->roles)) {
            return 'jd_manager';
        } elseif (in_array('transcriber', $user->roles)) {
            return 'transcriber';
        }
        return 'subscriber';
    }
    
    private function generate_orders_report($start_date, $end_date) {
        // Implementation for orders report
        $args = array(
            'post_type' => 'jd_order',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'date_query' => array(
                array(
                    'after' => $start_date,
                    'before' => $end_date,
                    'inclusive' => true,
                ),
            ),
        );
        
        $orders = get_posts($args);
        $report_data = array();
        
        foreach ($orders as $order) {
            $report_data[] = $this->format_order_data($order);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => array(
                'type' => 'orders',
                'period' => array(
                    'start' => $start_date,
                    'end' => $end_date,
                ),
                'orders' => $report_data,
                'summary' => array(
                    'total' => count($orders),
                    'completed' => count(array_filter($orders, function($o) {
                        return get_post_meta($o->ID, '_status', true) === 'completed';
                    })),
                ),
            ),
        ), 200);
    }
    
    private function generate_revenue_report($start_date, $end_date) {
        // Implementation for revenue report
        return new WP_REST_Response(array(
            'success' => true,
            'data' => array(
                'type' => 'revenue',
                'period' => array(
                    'start' => $start_date,
                    'end' => $end_date,
                ),
                'total_revenue' => 0, // Calculate actual revenue
                'breakdown' => array(), // Revenue breakdown by service type, etc.
            ),
        ), 200);
    }
    
    private function generate_transcribers_report($start_date, $end_date) {
        // Implementation for transcribers report
        return new WP_REST_Response(array(
            'success' => true,
            'data' => array(
                'type' => 'transcribers',
                'period' => array(
                    'start' => $start_date,
                    'end' => $end_date,
                ),
                'transcribers' => array(), // Transcriber performance data
            ),
        ), 200);
    }
    
    public function check_admin_permission($request) {
        return current_user_can('manage_options') || jd_is_admin_user();
    }
    
    public function check_super_admin_permission($request) {
        return current_user_can('manage_options');
    }
}