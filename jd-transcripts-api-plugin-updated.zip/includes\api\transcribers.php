<?php
/**
 * Transcribers API Endpoints
 * Replaces Node.js /api/transcribers routes
 */

class JD_API_Transcribers {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // GET /api/transcribers - Get all transcribers (public for filtering)
        register_rest_route($namespace, '/transcribers', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_transcribers'),
            'permission_callback' => '__return_true', // Public endpoint
            'args' => array(
                'specialization' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'availability' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'search' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'page' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 1,
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 20,
                ),
            ),
        ));
        
        // POST /api/transcribers - Create new transcriber
        register_rest_route($namespace, '/transcribers', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_transcriber'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'name' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'phone' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'specialization' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'hourlyRate' => array(
                    'required' => false,
                    'type' => 'number',
                ),
                'availability' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'available',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'experience' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
                'certifications' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field',
                ),
            ),
        ));
        
        // GET /api/transcribers/{id} - Get single transcriber
        register_rest_route($namespace, '/transcribers/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_transcriber'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PUT /api/transcribers/{id} - Update transcriber
        register_rest_route($namespace, '/transcribers/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_transcriber'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // DELETE /api/transcribers/{id} - Delete transcriber
        register_rest_route($namespace, '/transcribers/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_transcriber'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // DELETE /api/transcribers/clear - Clear all transcribers
        register_rest_route($namespace, '/transcribers/clear', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'clear_all_transcribers'),
            'permission_callback' => array($this, 'check_super_admin_permission'),
        ));
        
        // GET /api/transcribers/{id}/stats - Get transcriber statistics
        register_rest_route($namespace, '/transcribers/(?P<id>[a-zA-Z0-9-]+)/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_transcriber_stats'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PUT /api/transcribers/{id}/availability - Update transcriber availability
        register_rest_route($namespace, '/transcribers/(?P<id>[a-zA-Z0-9-]+)/availability', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_transcriber_availability'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'availability' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
    }
    
    /**
     * Get all transcribers with filtering
     */
    public function get_transcribers($request) {
        $params = $request->get_params();
        
        $args = array(
            'post_type' => 'jd_transcriber',
            'post_status' => 'publish',
            'posts_per_page' => $params['limit'],
            'paged' => $params['page'],
            'orderby' => 'title',
            'order' => 'ASC',
            'meta_query' => array(),
        );
        
        // Filter by specialization
        if (!empty($params['specialization']) && $params['specialization'] !== 'all') {
            $args['meta_query'][] = array(
                'key' => '_specialization',
                'value' => $params['specialization'],
                'compare' => '=',
            );
        }
        
        // Filter by availability
        if (!empty($params['availability']) && $params['availability'] !== 'all') {
            $args['meta_query'][] = array(
                'key' => '_availability',
                'value' => $params['availability'],
                'compare' => '=',
            );
        }
        
        // Search functionality
        if (!empty($params['search'])) {
            $args['meta_query'][] = array(
                'relation' => 'OR',
                array(
                    'key' => '_name',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
                array(
                    'key' => '_email',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
                array(
                    'key' => '_transcriber_id',
                    'value' => $params['search'],
                    'compare' => 'LIKE',
                ),
            );
        }
        
        $query = new WP_Query($args);
        $transcribers = array();
        
        foreach ($query->posts as $post) {
            $transcribers[] = $this->format_transcriber_data($post);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $transcribers,
            'pagination' => array(
                'current' => intval($params['page']),
                'pages' => $query->max_num_pages,
                'total' => $query->found_posts,
            ),
        ), 200);
    }
    
    /**
     * Create new transcriber
     */
    public function create_transcriber($request) {
        try {
            $params = $request->get_params();
            
            // Check if email already exists
            $existing = get_posts(array(
                'post_type' => 'jd_transcriber',
                'meta_query' => array(
                    array(
                        'key' => '_email',
                        'value' => $params['email'],
                        'compare' => '=',
                    ),
                ),
                'posts_per_page' => 1,
            ));
            
            if (!empty($existing)) {
                return new WP_Error('email_exists', 'A transcriber with this email already exists', array('status' => 400));
            }
            
            // Generate unique transcriber ID
            $transcriber_id = $this->generate_transcriber_id();
            
            // Create transcriber post
            $post_id = wp_insert_post(array(
                'post_title' => $params['name'] . ' - ' . $transcriber_id,
                'post_content' => $params['experience'] ?? '',
                'post_status' => 'publish',
                'post_type' => 'jd_transcriber',
                'post_author' => get_current_user_id(),
            ));
            
            if (is_wp_error($post_id)) {
                return new WP_Error('transcriber_creation_failed', 'Failed to create transcriber', array('status' => 500));
            }
            
            // Save transcriber metadata
            update_post_meta($post_id, '_transcriber_id', $transcriber_id);
            update_post_meta($post_id, '_name', $params['name']);
            update_post_meta($post_id, '_email', $params['email']);
            update_post_meta($post_id, '_phone', $params['phone'] ?? '');
            update_post_meta($post_id, '_specialization', $params['specialization']);
            update_post_meta($post_id, '_hourly_rate', $params['hourlyRate'] ?? 0);
            update_post_meta($post_id, '_availability', $params['availability']);
            update_post_meta($post_id, '_certifications', $params['certifications'] ?? '');
            update_post_meta($post_id, '_created_at', current_time('mysql'));
            update_post_meta($post_id, '_is_active', true);
            
            // Initialize statistics
            $this->initialize_transcriber_stats($post_id);
            
            // Create WordPress user account if needed
            if (!email_exists($params['email'])) {
                $user_id = wp_create_user(
                    sanitize_user($params['name']),
                    wp_generate_password(),
                    $params['email']
                );
                
                if (!is_wp_error($user_id)) {
                    $user = new WP_User($user_id);
                    $user->set_role('transcriber');
                    update_post_meta($post_id, '_user_id', $user_id);
                    update_user_meta($user_id, '_transcriber_post_id', $post_id);
                }
            }
            
            $transcriber_data = $this->format_transcriber_data(get_post($post_id));
            
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'Transcriber created successfully',
                'data' => $transcriber_data,
            ), 201);
            
        } catch (Exception $e) {
            return new WP_Error('transcriber_creation_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get single transcriber
     */
    public function get_transcriber($request) {
        $transcriber_id = $request['id'];
        $post = $this->get_transcriber_by_id($transcriber_id);
        
        if (!$post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        $transcriber_data = $this->format_transcriber_data($post);
        
        // Add detailed statistics
        $transcriber_data['statistics'] = $this->get_detailed_transcriber_stats($post->ID);
        
        // Add recent orders
        $transcriber_data['recentOrders'] = $this->get_transcriber_recent_orders($post->ID);
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $transcriber_data,
        ), 200);
    }
    
    /**
     * Update transcriber
     */
    public function update_transcriber($request) {
        $transcriber_id = $request['id'];
        $update_data = $request->get_json_params();
        
        $post = $this->get_transcriber_by_id($transcriber_id);
        if (!$post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        // Update post content if experience provided
        if (isset($update_data['experience'])) {
            wp_update_post(array(
                'ID' => $post->ID,
                'post_content' => sanitize_textarea_field($update_data['experience']),
            ));
        }
        
        // Update meta fields
        $meta_fields = array(
            'name' => '_name',
            'email' => '_email',
            'phone' => '_phone',
            'specialization' => '_specialization',
            'hourlyRate' => '_hourly_rate',
            'availability' => '_availability',
            'certifications' => '_certifications',
        );
        
        foreach ($meta_fields as $field => $meta_key) {
            if (isset($update_data[$field])) {
                update_post_meta($post->ID, $meta_key, sanitize_text_field($update_data[$field]));
            }
        }
        
        // Update timestamps
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        
        $updated_transcriber = $this->format_transcriber_data($post);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Transcriber updated successfully',
            'data' => $updated_transcriber,
        ), 200);
    }
    
    /**
     * Delete transcriber
     */
    public function delete_transcriber($request) {
        $transcriber_id = $request['id'];
        $post = $this->get_transcriber_by_id($transcriber_id);
        
        if (!$post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        // Check if transcriber has active orders
        $active_orders = get_posts(array(
            'post_type' => 'jd_order',
            'meta_query' => array(
                array(
                    'key' => '_assigned_to',
                    'value' => $post->ID,
                    'compare' => '=',
                ),
                array(
                    'key' => '_status',
                    'value' => array('pending', 'in-progress'),
                    'compare' => 'IN',
                ),
            ),
            'posts_per_page' => 1,
        ));
        
        if (!empty($active_orders)) {
            return new WP_Error('transcriber_has_active_orders', 'Cannot delete transcriber with active orders', array('status' => 400));
        }
        
        // Delete associated WordPress user
        $user_id = get_post_meta($post->ID, '_user_id', true);
        if ($user_id) {
            wp_delete_user($user_id);
        }
        
        // Delete transcriber statistics
        $this->delete_transcriber_stats($post->ID);
        
        // Delete the post
        wp_delete_post($post->ID, true);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Transcriber deleted successfully',
        ), 200);
    }
    
    /**
     * Clear all transcribers
     */
    public function clear_all_transcribers($request) {
        $transcribers = get_posts(array(
            'post_type' => 'jd_transcriber',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        ));
        
        $deleted_count = 0;
        
        foreach ($transcribers as $transcriber) {
            // Check for active orders
            $active_orders = get_posts(array(
                'post_type' => 'jd_order',
                'meta_query' => array(
                    array(
                        'key' => '_assigned_to',
                        'value' => $transcriber->ID,
                        'compare' => '=',
                    ),
                    array(
                        'key' => '_status',
                        'value' => array('pending', 'in-progress'),
                        'compare' => 'IN',
                    ),
                ),
                'posts_per_page' => 1,
            ));
            
            if (empty($active_orders)) {
                // Delete associated WordPress user
                $user_id = get_post_meta($transcriber->ID, '_user_id', true);
                if ($user_id) {
                    wp_delete_user($user_id);
                }
                
                // Delete transcriber statistics
                $this->delete_transcriber_stats($transcriber->ID);
                
                // Delete the post
                wp_delete_post($transcriber->ID, true);
                $deleted_count++;
            }
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => "Deleted {$deleted_count} transcribers successfully",
            'data' => array(
                'deleted' => $deleted_count,
                'total' => count($transcribers),
            ),
        ), 200);
    }
    
    /**
     * Get transcriber statistics
     */
    public function get_transcriber_stats($request) {
        $transcriber_id = $request['id'];
        $post = $this->get_transcriber_by_id($transcriber_id);
        
        if (!$post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        $stats = $this->get_detailed_transcriber_stats($post->ID);
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $stats,
        ), 200);
    }
    
    /**
     * Update transcriber availability
     */
    public function update_transcriber_availability($request) {
        $transcriber_id = $request['id'];
        $availability = $request['availability'];
        
        $post = $this->get_transcriber_by_id($transcriber_id);
        if (!$post) {
            return new WP_Error('transcriber_not_found', 'Transcriber not found', array('status' => 404));
        }
        
        update_post_meta($post->ID, '_availability', $availability);
        update_post_meta($post->ID, '_updated_at', current_time('mysql'));
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Transcriber availability updated successfully',
            'data' => array(
                'transcriberID' => $transcriber_id,
                'availability' => $availability,
            ),
        ), 200);
    }
    
    /**
     * Helper Functions
     */
    
    private function format_transcriber_data($post) {
        return array(
            'id' => $post->ID,
            'transcriberID' => get_post_meta($post->ID, '_transcriber_id', true),
            'name' => get_post_meta($post->ID, '_name', true),
            'email' => get_post_meta($post->ID, '_email', true),
            'phone' => get_post_meta($post->ID, '_phone', true),
            'specialization' => get_post_meta($post->ID, '_specialization', true),
            'hourlyRate' => floatval(get_post_meta($post->ID, '_hourly_rate', true)),
            'availability' => get_post_meta($post->ID, '_availability', true),
            'experience' => $post->post_content,
            'certifications' => get_post_meta($post->ID, '_certifications', true),
            'isActive' => get_post_meta($post->ID, '_is_active', true),
            'createdAt' => get_post_meta($post->ID, '_created_at', true),
            'updatedAt' => get_post_meta($post->ID, '_updated_at', true),
            'statistics' => $this->get_basic_transcriber_stats($post->ID),
        );
    }
    
    private function get_transcriber_by_id($transcriber_id) {
        $posts = get_posts(array(
            'post_type' => 'jd_transcriber',
            'meta_query' => array(
                array(
                    'key' => '_transcriber_id',
                    'value' => $transcriber_id,
                    'compare' => '=',
                ),
            ),
            'posts_per_page' => 1,
        ));
        
        return !empty($posts) ? $posts[0] : null;
    }
    
    private function generate_transcriber_id() {
        $prefix = 'TR';
        $timestamp = date('ymd');
        $random = wp_rand(100, 999);
        
        return $prefix . $timestamp . $random;
    }
    
    private function initialize_transcriber_stats($transcriber_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_transcriber_stats';
        
        $wpdb->insert(
            $table_name,
            array(
                'transcriber_id' => $transcriber_id,
                'total_orders' => 0,
                'completed_orders' => 0,
                'average_rating' => 0.00,
                'total_earnings' => 0.00,
            ),
            array('%d', '%d', '%d', '%f', '%f')
        );
    }
    
    private function get_basic_transcriber_stats($transcriber_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_transcriber_stats';
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE transcriber_id = %d",
            $transcriber_id
        ), ARRAY_A);
        
        if (!$stats) {
            return array(
                'totalOrders' => 0,
                'completedOrders' => 0,
                'averageRating' => 0.0,
                'totalEarnings' => 0.0,
            );
        }
        
        return array(
            'totalOrders' => intval($stats['total_orders']),
            'completedOrders' => intval($stats['completed_orders']),
            'averageRating' => floatval($stats['average_rating']),
            'totalEarnings' => floatval($stats['total_earnings']),
        );
    }
    
    private function get_detailed_transcriber_stats($transcriber_id) {
        $basic_stats = $this->get_basic_transcriber_stats($transcriber_id);
        
        // Get additional statistics
        $current_orders = get_posts(array(
            'post_type' => 'jd_order',
            'meta_query' => array(
                array(
                    'key' => '_assigned_to',
                    'value' => $transcriber_id,
                    'compare' => '=',
                ),
                array(
                    'key' => '_status',
                    'value' => array('pending', 'in-progress'),
                    'compare' => 'IN',
                ),
            ),
            'posts_per_page' => -1,
        ));
        
        $basic_stats['currentOrders'] = count($current_orders);
        $basic_stats['completionRate'] = $basic_stats['totalOrders'] > 0 
            ? round(($basic_stats['completedOrders'] / $basic_stats['totalOrders']) * 100, 2) 
            : 0;
        
        return $basic_stats;
    }
    
    private function get_transcriber_recent_orders($transcriber_id) {
        $orders = get_posts(array(
            'post_type' => 'jd_order',
            'meta_query' => array(
                array(
                    'key' => '_assigned_to',
                    'value' => $transcriber_id,
                    'compare' => '=',
                ),
            ),
            'posts_per_page' => 5,
            'orderby' => 'date',
            'order' => 'DESC',
        ));
        
        $recent_orders = array();
        foreach ($orders as $order) {
            $recent_orders[] = array(
                'orderId' => get_post_meta($order->ID, '_order_id', true),
                'clientName' => get_post_meta($order->ID, '_client_name', true),
                'serviceType' => get_post_meta($order->ID, '_service_type', true),
                'status' => get_post_meta($order->ID, '_status', true),
                'createdAt' => $order->post_date,
                'dueDate' => get_post_meta($order->ID, '_due_date', true),
            );
        }
        
        return $recent_orders;
    }
    
    private function delete_transcriber_stats($transcriber_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'jd_transcriber_stats';
        
        $wpdb->delete(
            $table_name,
            array('transcriber_id' => $transcriber_id),
            array('%d')
        );
    }
    
    public function check_admin_permission($request) {
        return current_user_can('manage_options') || jd_is_admin_user();
    }
    
    public function check_super_admin_permission($request) {
        return current_user_can('manage_options');
    }
}