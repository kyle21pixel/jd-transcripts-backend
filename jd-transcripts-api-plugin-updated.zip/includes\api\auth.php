<?php
/**
 * Authentication API Endpoints
 * Replaces Node.js /api/auth routes
 */

class JD_API_Auth {
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    public function register_routes() {
        $namespace = 'jd-api/v1';
        
        // POST /api/auth/login - Admin login
        register_rest_route($namespace, '/auth/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'admin_login'),
            'permission_callback' => '__return_true',
            'args' => array(
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'password' => array(
                    'required' => true,
                    'type' => 'string',
                ),
            ),
        ));
        
        // POST /api/auth/logout - Admin logout
        register_rest_route($namespace, '/auth/logout', array(
            'methods' => 'POST',
            'callback' => array($this, 'admin_logout'),
            'permission_callback' => array($this, 'check_authenticated'),
        ));
        
        // GET /api/auth/me - Get current user info
        register_rest_route($namespace, '/auth/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_current_user'),
            'permission_callback' => array($this, 'check_authenticated'),
        ));
        
        // POST /api/auth/register - Register new admin user (super admin only)
        register_rest_route($namespace, '/auth/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_admin'),
            'permission_callback' => array($this, 'check_super_admin_permission'),
            'args' => array(
                'username' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_user',
                ),
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'password' => array(
                    'required' => true,
                    'type' => 'string',
                ),
                'name' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'role' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => 'jd_manager',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));
        
        // PUT /api/auth/change-password - Change password
        register_rest_route($namespace, '/auth/change-password', array(
            'methods' => 'PUT',
            'callback' => array($this, 'change_password'),
            'permission_callback' => array($this, 'check_authenticated'),
            'args' => array(
                'currentPassword' => array(
                    'required' => true,
                    'type' => 'string',
                ),
                'newPassword' => array(
                    'required' => true,
                    'type' => 'string',
                ),
            ),
        ));
        
        // POST /api/auth/forgot-password - Request password reset
        register_rest_route($namespace, '/auth/forgot-password', array(
            'methods' => 'POST',
            'callback' => array($this, 'forgot_password'),
            'permission_callback' => '__return_true',
            'args' => array(
                'email' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
            ),
        ));
    }
    
    /**
     * Admin login
     */
    public function admin_login($request) {
        $email = $request['email'];
        $password = $request['password'];
        
        // Find user by email
        $user = get_user_by('email', $email);
        
        if (!$user) {
            return new WP_Error('invalid_credentials', 'Invalid email or password', array('status' => 401));
        }
        
        // Check if user has admin privileges
        if (!in_array('administrator', $user->roles) && !in_array('jd_manager', $user->roles)) {
            return new WP_Error('insufficient_privileges', 'Access denied. Admin privileges required.', array('status' => 403));
        }
        
        // Verify password
        if (!wp_check_password($password, $user->user_pass, $user->ID)) {
            return new WP_Error('invalid_credentials', 'Invalid email or password', array('status' => 401));
        }
        
        // Check if user is active
        $is_active = get_user_meta($user->ID, '_jd_user_active', true);
        if ($is_active === '0') {
            return new WP_Error('account_disabled', 'Your account has been disabled', array('status' => 403));
        }
        
        // Set user as logged in
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, true);
        
        // Update last login
        update_user_meta($user->ID, '_jd_last_login', current_time('mysql'));
        
        // Generate session token (simplified JWT alternative)
        $token = $this->generate_session_token($user);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Login successful',
            'data' => array(
                'token' => $token,
                'user' => array(
                    'id' => $user->ID,
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'name' => $user->display_name,
                    'role' => $this->get_user_primary_role($user),
                    'lastLogin' => get_user_meta($user->ID, '_jd_last_login', true),
                ),
            ),
        ), 200);
    }
    
    /**
     * Admin logout
     */
    public function admin_logout($request) {
        $current_user = wp_get_current_user();
        
        if ($current_user->ID) {
            // Clear session token
            delete_user_meta($current_user->ID, '_jd_session_token');
            
            // WordPress logout
            wp_logout();
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Logout successful',
        ), 200);
    }
    
    /**
     * Get current user info
     */
    public function get_current_user($request) {
        $current_user = wp_get_current_user();
        
        if (!$current_user->ID) {
            return new WP_Error('not_authenticated', 'User not authenticated', array('status' => 401));
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => array(
                'id' => $current_user->ID,
                'username' => $current_user->user_login,
                'email' => $current_user->user_email,
                'name' => $current_user->display_name,
                'role' => $this->get_user_primary_role($current_user),
                'lastLogin' => get_user_meta($current_user->ID, '_jd_last_login', true),
                'permissions' => $this->get_user_permissions($current_user),
            ),
        ), 200);
    }
    
    /**
     * Register new admin user
     */
    public function register_admin($request) {
        $username = $request['username'];
        $email = $request['email'];
        $password = $request['password'];
        $name = $request['name'] ?? '';
        $role = $request['role'];
        
        // Check if username exists
        if (username_exists($username)) {
            return new WP_Error('username_exists', 'Username already exists', array('status' => 400));
        }
        
        // Check if email exists
        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Email already exists', array('status' => 400));
        }
        
        // Validate role
        $allowed_roles = array('administrator', 'jd_manager', 'transcriber');
        if (!in_array($role, $allowed_roles)) {
            return new WP_Error('invalid_role', 'Invalid role specified', array('status' => 400));
        }
        
        // Create user
        $user_id = wp_create_user($username, $password, $email);
        
        if (is_wp_error($user_id)) {
            return new WP_Error('user_creation_failed', $user_id->get_error_message(), array('status' => 500));
        }
        
        // Set user role
        $user = new WP_User($user_id);
        $user->set_role($role);
        
        // Set display name
        if ($name) {
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $name,
            ));
        }
        
        // Set user as active
        update_user_meta($user_id, '_jd_user_active', '1');
        update_user_meta($user_id, '_jd_created_by', get_current_user_id());
        
        // Send welcome email
        $this->send_welcome_email($user, $password);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'User created successfully',
            'data' => array(
                'id' => $user_id,
                'username' => $username,
                'email' => $email,
                'role' => $role,
            ),
        ), 201);
    }
    
    /**
     * Change password
     */
    public function change_password($request) {
        $current_password = $request['currentPassword'];
        $new_password = $request['newPassword'];
        $current_user = wp_get_current_user();
        
        // Verify current password
        if (!wp_check_password($current_password, $current_user->user_pass, $current_user->ID)) {
            return new WP_Error('invalid_current_password', 'Current password is incorrect', array('status' => 400));
        }
        
        // Validate new password strength
        if (strlen($new_password) < 8) {
            return new WP_Error('weak_password', 'Password must be at least 8 characters long', array('status' => 400));
        }
        
        // Update password
        wp_set_password($new_password, $current_user->ID);
        
        // Update last password change
        update_user_meta($current_user->ID, '_jd_password_changed', current_time('mysql'));
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Password changed successfully',
        ), 200);
    }
    
    /**
     * Forgot password
     */
    public function forgot_password($request) {
        $email = $request['email'];
        
        $user = get_user_by('email', $email);
        
        if (!$user) {
            // Don't reveal if email exists or not for security
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'If the email exists, a password reset link has been sent',
            ), 200);
        }
        
        // Check if user has admin privileges
        if (!in_array('administrator', $user->roles) && !in_array('jd_manager', $user->roles)) {
            return new WP_REST_Response(array(
                'success' => true,
                'message' => 'If the email exists, a password reset link has been sent',
            ), 200);
        }
        
        // Generate reset key
        $reset_key = get_password_reset_key($user);
        
        if (is_wp_error($reset_key)) {
            return new WP_Error('reset_key_failed', 'Failed to generate reset key', array('status' => 500));
        }
        
        // Send reset email
        $this->send_password_reset_email($user, $reset_key);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'If the email exists, a password reset link has been sent',
        ), 200);
    }
    
    /**
     * Helper Functions
     */
    
    private function generate_session_token($user) {
        $token = wp_generate_password(32, false);
        update_user_meta($user->ID, '_jd_session_token', $token);
        update_user_meta($user->ID, '_jd_session_expires', time() + (24 * 60 * 60)); // 24 hours
        return $token;
    }
    
    private function get_user_primary_role($user) {
        if (in_array('administrator', $user->roles)) {
            return 'administrator';
        } elseif (in_array('jd_manager', $user->roles)) {
            return 'jd_manager';
        } elseif (in_array('transcriber', $user->roles)) {
            return 'transcriber';
        }
        return 'subscriber';
    }
    
    private function get_user_permissions($user) {
        $permissions = array();
        
        if (in_array('administrator', $user->roles)) {
            $permissions = array(
                'manage_orders',
                'manage_transcribers',
                'manage_users',
                'view_analytics',
                'manage_settings',
            );
        } elseif (in_array('jd_manager', $user->roles)) {
            $permissions = array(
                'manage_orders',
                'manage_transcribers',
                'view_analytics',
            );
        } elseif (in_array('transcriber', $user->roles)) {
            $permissions = array(
                'view_assigned_orders',
                'update_order_status',
            );
        }
        
        return $permissions;
    }
    
    private function send_welcome_email($user, $password) {
        $subject = 'Welcome to JD Legal Transcripts Admin Panel';
        
        $message = sprintf(
            '<h2>Welcome to JD Legal Transcripts</h2>
            <p>Hello %s,</p>
            <p>Your admin account has been created successfully.</p>
            <p><strong>Login Details:</strong></p>
            <ul>
                <li><strong>Username:</strong> %s</li>
                <li><strong>Email:</strong> %s</li>
                <li><strong>Temporary Password:</strong> %s</li>
            </ul>
            <p>Please log in and change your password immediately.</p>
            <p><strong>Admin Panel:</strong> <a href="%s">%s</a></p>',
            $user->display_name ?: $user->user_login,
            $user->user_login,
            $user->user_email,
            $password,
            admin_url(),
            admin_url()
        );
        
        jd_send_email_notification($user->user_email, $subject, $message);
    }
    
    private function send_password_reset_email($user, $reset_key) {
        $reset_url = network_site_url("wp-login.php?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login), 'login');
        
        $subject = 'Password Reset Request - JD Legal Transcripts';
        
        $message = sprintf(
            '<h2>Password Reset Request</h2>
            <p>Hello %s,</p>
            <p>A password reset has been requested for your account.</p>
            <p>If you did not request this, please ignore this email.</p>
            <p>To reset your password, click the link below:</p>
            <p><a href="%s">Reset Password</a></p>
            <p>This link will expire in 24 hours.</p>',
            $user->display_name ?: $user->user_login,
            $reset_url
        );
        
        jd_send_email_notification($user->user_email, $subject, $message);
    }
    
    public function check_authenticated($request) {
        $current_user = wp_get_current_user();
        
        if (!$current_user->ID) {
            // Check for session token in headers
            $token = $request->get_header('Authorization');
            if ($token && strpos($token, 'Bearer ') === 0) {
                $token = substr($token, 7);
                $user = $this->validate_session_token($token);
                if ($user) {
                    wp_set_current_user($user->ID);
                    return true;
                }
            }
            return false;
        }
        
        return true;
    }
    
    private function validate_session_token($token) {
        global $wpdb;
        
        $user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} 
             WHERE meta_key = '_jd_session_token' 
             AND meta_value = %s",
            $token
        ));
        
        if (!$user_id) {
            return false;
        }
        
        // Check if token is expired
        $expires = get_user_meta($user_id, '_jd_session_expires', true);
        if ($expires && time() > $expires) {
            delete_user_meta($user_id, '_jd_session_token');
            delete_user_meta($user_id, '_jd_session_expires');
            return false;
        }
        
        return get_user_by('id', $user_id);
    }
    
    public function check_super_admin_permission($request) {
        return current_user_can('manage_options');
    }
}