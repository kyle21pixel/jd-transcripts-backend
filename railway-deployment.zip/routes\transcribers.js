const express = require('express');
const router = express.Router();
const Transcriber = require('../models/Transcriber');
const auth = require('../middleware/auth');

// @route   GET /api/transcribers
// @desc    Get all transcribers
// @access  Private
router.get('/', auth, async (req, res) => {
    try {
        const { status, specialization, available } = req.query;
        
        let query = {};
        
        // Filter by status
        if (status) {
            query.status = status;
        }
        
        // Filter by specialization
        if (specialization) {
            query.specialization = specialization;
        }
        
        // Filter by availability
        if (available === 'true') {
            query.isAvailable = true;
        }

        const transcribers = await Transcriber.find(query)
            .select('-password')
            .sort({ name: 1 });

        res.json({
            success: true,
            data: transcribers
        });
    } catch (error) {
        console.error('Error fetching transcribers:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch transcribers',
            error: error.message
        });
    }
});

// @route   GET /api/transcribers/:id
// @desc    Get single transcriber
// @access  Private
router.get('/:id', auth, async (req, res) => {
    try {
        const transcriber = await Transcriber.findOne({ transcriberID: req.params.id })
            .select('-password');

        if (!transcriber) {
            return res.status(404).json({
                success: false,
                message: 'Transcriber not found'
            });
        }

        res.json({
            success: true,
            data: transcriber
        });
    } catch (error) {
        console.error('Error fetching transcriber:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch transcriber',
            error: error.message
        });
    }
});

// @route   POST /api/transcribers
// @desc    Create new transcriber
// @access  Private
router.post('/', auth, async (req, res) => {
    try {
        const {
            name,
            email,
            phone,
            specialization,
            hourlyRate,
            maxConcurrentOrders
        } = req.body;

        // Check if transcriber already exists
        const existingTranscriber = await Transcriber.findOne({ email });
        if (existingTranscriber) {
            return res.status(400).json({
                success: false,
                message: 'Transcriber with this email already exists'
            });
        }

        const transcriber = new Transcriber({
            name,
            email,
            phone,
            specialization,
            hourlyRate,
            maxConcurrentOrders
        });

        await transcriber.save();

        res.status(201).json({
            success: true,
            message: 'Transcriber created successfully',
            data: {
                transcriberID: transcriber.transcriberID,
                name: transcriber.name,
                email: transcriber.email,
                specialization: transcriber.specialization
            }
        });
    } catch (error) {
        console.error('Error creating transcriber:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create transcriber',
            error: error.message
        });
    }
});

// @route   PUT /api/transcribers/:id
// @desc    Update transcriber
// @access  Private
router.put('/:id', auth, async (req, res) => {
    try {
        const transcriber = await Transcriber.findOne({ transcriberID: req.params.id });

        if (!transcriber) {
            return res.status(404).json({
                success: false,
                message: 'Transcriber not found'
            });
        }

        const {
            name,
            email,
            phone,
            specialization,
            hourlyRate,
            maxConcurrentOrders,
            isAvailable,
            status
        } = req.body;

        // Update fields
        if (name) transcriber.name = name;
        if (email) transcriber.email = email;
        if (phone) transcriber.phone = phone;
        if (specialization) transcriber.specialization = specialization;
        if (hourlyRate) transcriber.hourlyRate = hourlyRate;
        if (maxConcurrentOrders) transcriber.maxConcurrentOrders = maxConcurrentOrders;
        if (typeof isAvailable !== 'undefined') transcriber.isAvailable = isAvailable;
        if (status) transcriber.status = status;

        await transcriber.save();

        res.json({
            success: true,
            message: 'Transcriber updated successfully',
            data: transcriber
        });
    } catch (error) {
        console.error('Error updating transcriber:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update transcriber',
            error: error.message
        });
    }
});

// @route   DELETE /api/transcribers/:id
// @desc    Delete transcriber
// @access  Private
router.delete('/:id', auth, async (req, res) => {
    try {
        const transcriber = await Transcriber.findOne({ transcriberID: req.params.id });

        if (!transcriber) {
            return res.status(404).json({
                success: false,
                message: 'Transcriber not found'
            });
        }

        await transcriber.deleteOne();

        res.json({
            success: true,
            message: 'Transcriber deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting transcriber:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete transcriber',
            error: error.message
        });
    }
});

// @route   GET /api/transcribers/stats/performance
// @desc    Get transcriber performance statistics
// @access  Private
router.get('/stats/performance', auth, async (req, res) => {
    try {
        const transcribers = await Transcriber.find({ status: 'active' })
            .select('name transcriberID statistics specialization')
            .sort({ 'statistics.averageRating': -1 });

        res.json({
            success: true,
            data: transcribers
        });
    } catch (error) {
        console.error('Error fetching transcriber performance:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch transcriber performance',
            error: error.message
        });
    }
});

module.exports = router;