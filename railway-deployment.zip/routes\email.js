const express = require('express');
const router = express.Router();
const emailController = require('../controllers/emailController');

// @route   POST /api/email/contact
// @desc    Send contact form email
// @access  Public
router.post('/contact', async (req, res) => {
    try {
        const { name, email, message, subject } = req.body;

        // Validate required fields
        if (!name || !email || !message) {
            return res.status(400).json({
                success: false,
                message: 'Name, email, and message are required'
            });
        }

        // Send contact email
        await emailController.sendContactEmail({
            name,
            email,
            message,
            subject: subject || 'New Contact Form Submission'
        });

        res.json({
            success: true,
            message: 'Contact email sent successfully'
        });
    } catch (error) {
        console.error('Error sending contact email:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to send contact email',
            error: error.message
        });
    }
});

// @route   POST /api/email/order-confirmation
// @desc    Send order confirmation email
// @access  Public
router.post('/order-confirmation', async (req, res) => {
    try {
        const orderData = req.body;

        await emailController.sendOrderConfirmation(orderData);

        res.json({
            success: true,
            message: 'Order confirmation email sent successfully'
        });
    } catch (error) {
        console.error('Error sending order confirmation:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to send order confirmation email',
            error: error.message
        });
    }
});

module.exports = router;